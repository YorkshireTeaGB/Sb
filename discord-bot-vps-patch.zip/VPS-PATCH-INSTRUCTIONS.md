# VPS patch instructions

The ZIP contains replacement source files under `src/`, plus this guide and a list of music-only files to delete.

1. Back up the bot's source and `data/` directory.
2. Extract the ZIP over the bot package root, preserving the `src/` paths.
3. Delete the three paths listed in `DELETE-MUSIC-FILES.txt`. ZIP extraction does not remove old files.
4. Keep the existing `.env` and `data/` files unchanged.
5. Build using the VPS's existing TypeScript build command, then restart the existing PM2 process.
6. Run the slash-command deployment once with the same `DISCORD_GUILD_ID` setting used for the current commands. From the workspace root:

   ```sh
   pnpm --filter @workspace/discord-bot run deploy-commands
   ```

   From the bot package directory, use `pnpm run deploy-commands`. This replaces the registered command list and removes `/play`, `/skip`, `/pause`, `/stop`, `/shuffle`, `/back`, and `/queue`.

## Permissions and behavior

- The bot joins tracked voice channel `872289832066482262` when a person enters and leaves when the channel becomes empty. It is visible in that channel while monitoring and must be allowed to Connect without self-deafening.
- Members with no detected incoming voice packets for 45 minutes are moved to the channel named by `AFK_CHANNEL_NAME` (defaults to `afk`). The bot needs Move Members permission in both channels.
- Packet activity is only a proxy for speaking. No audio is stored or transcribed. Background audio and modified clients that send continuous packets may count as activity.
- The bot itself is excluded from VC time, VC-time coin rewards, and all leaderboard displays.
- Soundboard playback requires Connect, Speak, and Use Soundboard permissions. Failed playback returns the one-use item to inventory.

The bot token and all other `.env` values remain on the VPS and are not included in the ZIP.
