import { readFileSync, writeFileSync, mkdirSync, existsSync } from "fs";
import { join } from "path";
import { Client, TextChannel } from "discord.js";
import { addCoins } from "./coins.js";

const DATA_DIR = join(process.cwd(), "data");
const DATA_FILE = join(DATA_DIR, "vcStats.json");

const TOP_REWARDS = [9, 5, 3];
const PARTICIPATION_MIN_SECONDS = 5 * 60 * 60;
const ANNOUNCE_CHANNEL_ID = "1512995703956439241";
const medals = ["🥇", "🥈", "🥉"];

let _client: Client | null = null;
export function setVcStatsClient(client: Client): void {
  _client = client;
}

function isBotAccount(guildId: string, userId: string): boolean {
  if (_client?.user?.id === userId) return true;
  return _client?.guilds.cache.get(guildId)?.members.cache.get(userId)?.user.bot === true;
}

interface VcStatsData {
  weekStart: string;
  guilds: Record<string, Record<string, number>>;
}

function getMondayMidnightUTC(): Date {
  const now = new Date();
  const day = now.getUTCDay();
  const diff = day === 0 ? 6 : day - 1;
  const monday = new Date(now);
  monday.setUTCDate(now.getUTCDate() - diff);
  monday.setUTCHours(0, 0, 0, 0);
  return monday;
}

function nextMondayMidnightUTC(): Date {
  const monday = getMondayMidnightUTC();
  monday.setUTCDate(monday.getUTCDate() + 7);
  return monday;
}

function load(): VcStatsData {
  if (!existsSync(DATA_FILE)) {
    return { weekStart: getMondayMidnightUTC().toISOString(), guilds: {} };
  }
  try {
    return JSON.parse(readFileSync(DATA_FILE, "utf-8")) as VcStatsData;
  } catch {
    return { weekStart: getMondayMidnightUTC().toISOString(), guilds: {} };
  }
}

function save(data: VcStatsData): void {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
  writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
}

async function announceVcWinners(
  guildId: string,
  sorted: [string, number][]
): Promise<void> {
  if (!_client) return;
  const guild = _client.guilds.cache.get(guildId);
  const lines: string[] = [];

  for (let i = 0; i < sorted.length; i++) {
    const [userId] = sorted[i]!;
    if (i < TOP_REWARDS.length) {
      const reward = TOP_REWARDS[i]!;
      let name = `<@${userId}>`;
      if (guild) {
        const member = await guild.members.fetch(userId).catch(() => null);
        if (member) name = member.displayName;
      }
      const prefix = medals[i] ?? `**${i + 1}.**`;
      lines.push(`${prefix} **${name}** — **+${reward} coin${reward === 1 ? "" : "s"}**`);
    }
  }

  if (lines.length === 0) return;

  try {
    const channel = _client.channels.cache.get(ANNOUNCE_CHANNEL_ID) as TextChannel | undefined;
    if (channel) {
      await channel.send(
        `🎙️ **Weekly VC Leaderboard Reset!**\n\n${lines.join("\n")}\n\n*Top 3 earn 9/5/3 coins. Anyone with 5+ hours of VC time also earns 1 coin.*`
      );
    }
  } catch (err) {
    console.error("VC announcement error:", err);
  }
}

function awardWeeklyCoins(data: VcStatsData): void {
  for (const [guildId, guildStats] of Object.entries(data.guilds)) {
    const sorted = Object.entries(guildStats)
      .filter(([userId]) => !isBotAccount(guildId, userId))
      .sort(([, a], [, b]) => b - a);

    sorted.forEach(([userId, seconds], i) => {
      if (i < TOP_REWARDS.length) {
        const reward = TOP_REWARDS[i]!;
        addCoins(userId, reward);
        console.log(`🪙 Awarded ${reward} coin(s) to ${userId} (place ${i + 1}) in guild ${guildId}`);
      } else if (seconds >= PARTICIPATION_MIN_SECONDS) {
        addCoins(userId, 1);
        console.log(`🪙 Awarded 1 coin to ${userId} (participation, ${Math.floor(seconds / 3600)}h) in guild ${guildId}`);
      } else {
        console.log(`⏭️ No coin for ${userId} — only ${Math.floor(seconds / 3600)}h this week (need 5h) in guild ${guildId}`);
      }
    });

    announceVcWinners(guildId, sorted).catch(console.error);
  }
}

function checkAndReset(data: VcStatsData): VcStatsData {
  const currentWeekStart = getMondayMidnightUTC();
  const storedWeekStart = new Date(data.weekStart);
  if (storedWeekStart < currentWeekStart) {
    console.log(`📅 New week — awarding coins then resetting VC stats (was: ${data.weekStart})`);
    awardWeeklyCoins(data);
    return { weekStart: currentWeekStart.toISOString(), guilds: {} };
  }
  return data;
}

export function addSeconds(guildId: string, userId: string, seconds: number): void {
  if (seconds <= 0 || isBotAccount(guildId, userId)) return;
  let data = load();
  data = checkAndReset(data);
  if (!data.guilds[guildId]) data.guilds[guildId] = {};
  data.guilds[guildId][userId] = (data.guilds[guildId][userId] ?? 0) + seconds;
  save(data);
}

export function getGuildStats(guildId: string): Record<string, number> {
  let data = load();
  data = checkAndReset(data);
  save(data);
  return Object.fromEntries(
    Object.entries(data.guilds[guildId] ?? {}).filter(([userId]) => !isBotAccount(guildId, userId)),
  );
}

export function getBanterTargetUserIds(guildId: string): string[] {
  const stats = getGuildStats(guildId);
  return Object.entries(stats)
    .sort(([, a], [, b]) => b - a)
    .filter(([, seconds], index) => index < TOP_REWARDS.length || seconds >= PARTICIPATION_MIN_SECONDS)
    .map(([userId]) => userId);
}

export function getWeekStart(): Date {
  const data = load();
  return new Date(data.weekStart);
}

export function getNextReset(): Date {
  return nextMondayMidnightUTC();
}
