import { readFileSync, writeFileSync, mkdirSync, existsSync } from "fs";
import { join } from "path";
import { Client, TextChannel } from "discord.js";
import { addCoins } from "./coins.js";

const DATA_DIR = join(process.cwd(), "data");
const DATA_FILE = join(DATA_DIR, "chatStats.json");

const MIN_MESSAGES_FOR_REWARD = 15;
const ANNOUNCE_CHANNEL_ID = "1512995703956439241";
const medals = ["🥇", "🥈", "🥉"];
const TOP_REWARDS = [9, 5, 3];
const PARTICIPATION_REWARD = 1;

let _client: Client | null = null;
export function setChatStatsClient(client: Client): void {
  _client = client;
}

function isBotAccount(guildId: string, userId: string): boolean {
  if (_client?.user?.id === userId) return true;
  return _client?.guilds.cache.get(guildId)?.members.cache.get(userId)?.user.bot === true;
}

interface ChatStatsData {
  weekStart: string;
  guilds: Record<string, Record<string, number>>;
}

function getMondayMidnightUTC(): Date {
  const now = new Date();
  const day = now.getUTCDay();
  const diff = day === 0 ? 6 : day - 1;
  const monday = new Date(now);
  monday.setUTCDate(now.getUTCDate() - diff);
  monday.setUTCHours(0, 0, 0, 0);
  return monday;
}

function load(): ChatStatsData {
  if (!existsSync(DATA_FILE)) {
    return { weekStart: getMondayMidnightUTC().toISOString(), guilds: {} };
  }
  try {
    return JSON.parse(readFileSync(DATA_FILE, "utf-8")) as ChatStatsData;
  } catch {
    return { weekStart: getMondayMidnightUTC().toISOString(), guilds: {} };
  }
}

function save(data: ChatStatsData): void {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
  writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
}

async function announceAndAward(data: ChatStatsData): Promise<void> {
  for (const [guildId, guildStats] of Object.entries(data.guilds)) {
    const qualifying = Object.entries(guildStats)
      .filter(([userId, count]) => !isBotAccount(guildId, userId) && count >= MIN_MESSAGES_FOR_REWARD)
      .sort(([, a], [, b]) => b - a);

    if (qualifying.length === 0) continue;

    const lines: string[] = [];
    const guild = _client?.guilds.cache.get(guildId);

    for (let i = 0; i < qualifying.length; i++) {
      const [userId, msgCount] = qualifying[i]!;
      const reward = i < TOP_REWARDS.length ? TOP_REWARDS[i]! : PARTICIPATION_REWARD;
      addCoins(userId, reward);

      let name = `<@${userId}>`;
      if (guild) {
        const member = await guild.members.fetch(userId).catch(() => null);
        if (member) name = member.displayName;
      }

      const prefix = medals[i] ?? `**${i + 1}.**`;
      if (i < 3) {
        lines.push(`${prefix} **${name}** — ${msgCount} messages · **+${reward} coin${reward === 1 ? "" : "s"}**`);
      }

      console.log(`💬 Chat coin awarded to ${userId}: +${reward} (${msgCount} msgs, rank ${i + 1}) in guild ${guildId}`);
    }

    if (lines.length > 0 && _client) {
      try {
        const channel = _client.channels.cache.get(ANNOUNCE_CHANNEL_ID) as TextChannel | undefined;
        if (channel) {
          await channel.send(
            `💬 **Weekly Chat Leaderboard Reset!**\n\n${lines.join("\n")}\n\n*Top 3 earn 9/5/3 coins. Everyone with 15+ qualifying messages earns 1 coin.*`
          );
        }
      } catch (err) {
        console.error("Chat announcement error:", err);
      }
    }
  }
}

function checkAndReset(data: ChatStatsData): ChatStatsData {
  const currentWeekStart = getMondayMidnightUTC();
  const storedWeekStart = new Date(data.weekStart);
  if (storedWeekStart < currentWeekStart) {
    console.log(`📅 New week — awarding chat coins then resetting (was: ${data.weekStart})`);
    announceAndAward(data).catch(console.error);
    return { weekStart: currentWeekStart.toISOString(), guilds: {} };
  }
  return data;
}

export function recordMessage(userId: string, guildId: string): void {
  if (isBotAccount(guildId, userId)) return;
  let data = load();
  data = checkAndReset(data);
  if (!data.guilds[guildId]) data.guilds[guildId] = {};
  data.guilds[guildId][userId] = (data.guilds[guildId][userId] ?? 0) + 1;
  save(data);
}

export function getGuildChatStats(guildId: string): Record<string, number> {
  let data = load();
  data = checkAndReset(data);
  save(data);
  return Object.fromEntries(
    Object.entries(data.guilds[guildId] ?? {}).filter(([userId]) => !isBotAccount(guildId, userId)),
  );
}

export function getChatBanterTargetUserIds(guildId: string): string[] {
  const stats = getGuildChatStats(guildId);
  return Object.entries(stats)
    .sort(([, a], [, b]) => b - a)
    .filter(([, count], index) => index < TOP_REWARDS.length || count >= MIN_MESSAGES_FOR_REWARD)
    .map(([userId]) => userId);
}

export function getWeekStart(): Date {
  const data = load();
  return new Date(data.weekStart);
}
