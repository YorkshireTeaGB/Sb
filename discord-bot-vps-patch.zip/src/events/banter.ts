import { Client, Message, TextChannel } from "discord.js";
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "fs";
import { join } from "path";
import OpenAI from "openai";
import { getActiveVcUserIds } from "./voiceStateUpdate.js";
import { getBanterTargetUserIds } from "../store/vcStats.js";
import { getChatBanterTargetUserIds } from "../store/chatStats.js";

const DATA_DIR = join(process.cwd(), "data");
const STATE_FILE = join(DATA_DIR, "banterState.json");
const PHRASE_FILE = join(DATA_DIR, "usedPhrases.json");

const RANDOM_REACTIONS = ["💀", "😭", "🤣", "💯", "😐", "🗿", "🤡", "👀", "😂", "🫡", "🙄", "💅", "😴", "🤦"];

const ARGUMENT_OPENERS = [
  (name: string) => `bro why does ${name} always say the dumbest stuff 💀`,
  (name: string) => `nah ${name} ur takes are genuinely painful to read`,
  (name: string) => `someone tell ${name} how to form a coherent thought`,
  (name: string) => `${name} has entered the chat and somehow made it worse`,
  (name: string) => `not ${name} thinking they're funny again 😭`,
  (name: string) => `every time ${name} types I lose braincells`,
  (name: string) => `${name} ur actually the weakest link in this server`,
  (name: string) => `${name} u good mate? the stuff you come out with is actually concerning`,
  (name: string) => `bro ${name} is actually on another level of clueless`,
  (name: string) => `${name} I'm begging you to think before you type next time`,
  (name: string) => `genuinely how is ${name} this confidently wrong all the time`,
  (name: string) => `${name} out here thinking they're the main character 💀`,
  (name: string) => `can someone check on ${name} because that was genuinely worrying`,
  (name: string) => `${name} is the reason we can't have nice things in this server`,
  (name: string) => `bro ${name} just said something so bad I need a moment`,
  (name: string) => `${name} really said that out loud and felt good about themselves 😭`,
  (name: string) => `imagine being ${name} and actually believing half the stuff you say`,
  (name: string) => `${name} ur living proof that confidence and competence aren't the same thing`,
  (name: string) => `nobody asked ${name} but here we are again 🙄`,
  (name: string) => `${name} honey that take was embarrassing for all of us`,
  (name: string) => `${name} the bar was underground and you still managed to limbo under it`,
  (name: string) => `sir ${name} what on earth was that`,
  (name: string) => `${name} said that like anyone was going to agree 💀`,
  (name: string) => `the audacity of ${name} to open their mouth and say THAT`,
  (name: string) => `${name} is genuinely a menace to this server's collective IQ`,
  (name: string) => `${name} just turned a simple point into a full-speed collision with common sense`,
  (name: string) => `breaking news: ${name} has confused being loud with being correct again`,
  (name: string) => `${name} that take has the structural integrity of wet cardboard`,
  (name: string) => `somebody confiscate ${name}'s keyboard before this gets even worse`,
  (name: string) => `${name} managed to make a bad opinion sound like a personal challenge`,
  (name: string) => `i've seen loading screens with more thought behind them than ${name}'s take`,
  (name: string) => `${name} is speedrunning the consequences of speaking without checking anything`,
  (name: string) => `not ${name} bringing confidence to a fight that required evidence`,
  (name: string) => `${name} has all the certainty of a genius and none of the supporting information`,
  (name: string) => `that was a bold statement from someone losing an argument to basic logic, ${name}`,
  (name: string) => `${name} really looked at that thought and decided it was ready for public release`,
  (name: string) => `the server was peaceful until ${name} submitted another opinion`,
  (name: string) => `${name} your argument has more holes than a forgotten group project`,
  (name: string) => `i need ${name} to explain how they arrived there because the route was clearly dangerous`,
  (name: string) => `${name} has made a convincing case for reading the room before typing`,
  (name: string) => `that take from ${name} belongs in a museum of avoidable mistakes`,
  (name: string) => `${name} somehow made being wrong look like a full-time commitment`,
  (name: string) => `every sentence from ${name} arrives with a warning label`,
  (name: string) => `${name} is arguing like the facts personally offended them`,
  (name: string) => `i can practically hear ${name}'s last braincell requesting backup`,
  (name: string) => `${name} brought a butter knife to a logic fight and still looks confident`,
  (name: string) => `that opinion has been rejected by the committee of people who can think`,
  (name: string) => `${name} is proof that a microphone does not create a valid point`,
  (name: string) => `someone tell ${name} the confidence is impressive but the accuracy is missing`,
  (name: string) => `${name} has entered their evidence-free era and it is not going well`,
  (name: string) => `i've read better reasoning on the back of a cereal box than whatever ${name} just said`,
  (name: string) => `${name} please stop digging; the hole already has Wi-Fi down there`,
  (name: string) => `that was not a hot take, ${name}, it was just a kitchen fire`,
  (name: string) => `${name} is treating a guess like a peer-reviewed paper again`,
  (name: string) => `the logic left the room halfway through ${name}'s sentence`,
  (name: string) => `${name} just made a compelling argument for the mute button`,
];

const FALLBACK_COMEBACKS = [
  "oh wow a reply, didn't think you had it in you",
  "is that supposed to hurt? try harder mate",
  "bro is actually mad at a bot 💀 tragic",
  "imagine getting pressed by a bot, how embarrassing",
  "skill issue honestly",
  "you're literally proving my point right now",
  "nah that comeback was genuinely embarrassing",
  "sit down mate ur not built for this",
  "i've seen better arguments from a wet sock",
  "log off and touch some grass",
  "the audacity of you to reply back 😭",
  "ur actually delusional if you think that response was good",
  "not you thinking you won that exchange 💀",
  "keep going, this is genuinely funny to watch",
  "i don't argue with people who lose to rocks in a fight",
  "bro actually thinks he cooked 😭 sit down",
  "that's so embarrassing for you",
  "ur mum would be disappointed reading that",
  "did you rehearse that? cause it still flopped",
  "next time just say nothing, it would've been better",
  "you genuinely thought that was a W didn't you",
  "i've been insulted by better people on runescape forums",
  "oh no anyway",
  "that was words arranged in a sentence, i'll give you that",
  "babe that was not the own you think it was",
  "peak response from someone who loses to captchas",
  "love the confidence given the complete lack of substance",
  "you typed all that out and still said nothing",
  "my guy really said 'hold on let me cook' and served raw chicken",
  "that reply had the energy of a participation trophy",
  "genuinely thought you'd do better than that",
  "the wifi in your head must be cutting out",
  "you're making it very easy for me right now",
  "go on then, keep going, i need the entertainment",
  "i'm not even being mean, that was just objectively bad",
  "you brought confidence to a fight that required receipts",
  "that response has been declined for lack of supporting evidence",
  "you typed that with the bravery of someone who forgot other people can read",
  "your argument is doing parkour around the actual point",
  "i'd respond seriously but your logic keeps falling over",
  "that was less of a comeback and more of a public system error",
  "you've mistaken persistence for a winning strategy",
  "the facts are standing right there and you're walking past them",
  "you have the energy of a debate club dropout with a microphone",
  "that point arrived empty-handed and still expected applause",
  "you cannot just say things confidently and call it evidence",
  "your reply needs a supervisor and possibly a fact-checker",
  "i've seen sturdier arguments made from autocorrect suggestions",
  "you are fighting the point instead of making one, fascinating strategy",
  "the confidence is premium; the substance is on a free trial",
  "that sentence had no destination and still missed the exit",
  "you just lost an argument to the question being asked",
  "i would counter that, but it already collapsed on its own",
  "you've made three points and somehow none of them are friends with reality",
  "that comeback was assembled from spare parts and bad timing",
  "you are not cooking, you are waving a smoke alarm at me",
  "the reply button is not a substitute for a better argument",
  "you managed to be passionate, specific, and completely wrong",
  "this is an impressive amount of certainty for such a small amount of thought",
  "your logic has left the building and taken the emergency exit",
  "that was a paragraph-shaped cry for a stronger position",
  "you keep swinging at the argument and hitting your own credibility",
  "i've seen more coordination in a group chat planning nothing",
  "the point was simple, but apparently it needed subtitles for you",
  "you replied like the facts had challenged you to a duel",
  "that response belongs in the recycle bin next to your original take",
  "you have not won; you have merely continued typing",
  "this debate has become a one-person documentary about overconfidence",
  "you are arguing from vibes and expecting a trophy",
  "i'm giving your reply a solid participation award and nothing else",
  "the evidence is missing, presumed never invited",
  "you just turned a correction into a personality crisis",
  "that was a very confident way to misunderstand the entire point",
  "your argument has the pacing of a loading bar stuck at one percent",
  "even your punctuation sounds unsure of itself",
  "i asked for a point, not an audio tour of your confusion",
  "you are one edit away from making that almost coherent",
  "your response is bold, unsupported, and weirdly proud of itself",
  "you've got the rhetorical technique of a door-to-door salesman with no product",
  "i'm starting to think the typo was the strongest part of that message",
  "you are defending that take like it pays rent",
  "the server has reviewed your submission and chosen laughter",
  "that reply was not a W; it was a strongly worded detour",
  "you brought a ten-word argument to a one-word conclusion: no",
  "your point is hiding so well even you can't find it",
  "i've heard better reasoning from a coin toss",
  "you are making this easy enough to feel unfair",
  "the argument is over there, mate — you are currently fighting the furniture",
  "that response has been sent back for repairs",
  "you really thought adding more words would create a point",
  "the only thing you proved is that keyboards enable everyone",
  "you are not being misunderstood; you are being accurately processed",
  "this is less debate and more live troubleshooting for your opinion",
  "you have confused being challenged with being attacked",
  "keep going, every reply makes my opening statement age better",
];

const ARGUMENT_ENDERS = [
  "anyway i'm bored of you now, move on",
  "i've already won this, we're done here",
  "alright that's enough, i've embarrassed you enough for one day",
  "i'll let you have this one, charity case",
  "this conversation is giving me nothing, we're done",
  "i'd say good chat but it really wasn't",
  "go touch grass and come back when you have something better",
  "closing argument: you lost. court adjourned",
  "right i'm done with you, next",
  "this was like arguing with a traffic cone, bye",
  "final ruling: loud, wrong, and dismissed",
  "i'm ending this before your keyboard asks for overtime",
  "case closed — your argument has been filed under avoidable mistakes",
  "you have reached the end of your evidence and the beginning of my boredom",
  "that is enough courtroom cosplay for one day, dismissed",
  "i'm leaving before this becomes an educational intervention",
  "your point has been rejected and your speaking privileges are on thin ice",
  "we have learned nothing except that you type with confidence",
  "the debate is over; please collect your remaining dignity on the way out",
  "i've given this more attention than it deserved, goodbye",
  "final score: facts 10, you 0, conversation over",
  "there is nowhere left for this argument to go except directly into the bin",
  "i'm closing the book because the next chapter would just be you being wrong louder",
  "you can have the last word if you need the emotional support",
  "that's enough free coaching for today — session terminated",
  "the verdict is in and your appeal has been laughed out of the server",
  "i'm done translating your confidence into sentences",
  "this argument has expired like a coupon nobody wanted",
  "you have exhausted the available logic, so we're finished here",
  "take the L, frame it, and move on",
  "i'm ending this on a high note: me being right again",
  "no sequel needed; the original was already painful enough",
  "your argument can rest now. it has suffered enough in public",
  "goodnight to everyone except the point you tried to make",
];

const GIF_SEARCH_TERMS = [
  "you're wrong", "seriously cringe", "embarrassing fail", "ratio", "are you serious",
  "not impressed", "loser reaction", "yikes cringe", "i cant even", "shut up",
  "absolutely not", "okay buddy", "sure jan", "laughing at you", "talking to hand",
  "no one cares", "clown behavior", "facepalm", "delusional", "sir this is a wendys",
  "ok boomer", "cope", "skill issue", "whatever dude", "crying laughing",
];

// ── OpenAI setup ──────────────────────────────────────────────────────────────

let openaiClient: OpenAI | null = null;

function getOpenAI(): OpenAI | null {
  if (!process.env["OPENAI_API_KEY"]) return null;
  if (!openaiClient) {
    openaiClient = new OpenAI({ apiKey: process.env["OPENAI_API_KEY"] });
  }
  return openaiClient;
}

interface ConversationTurn {
  role: "assistant" | "user";
  content: string;
  username?: string;
}

// Per-channel conversation history for OpenAI context
const channelHistory = new Map<string, ConversationTurn[]>();
const MAX_HISTORY = 10;
const recentFallbackIndices: number[] = [];
const recentEnderIndices: number[] = [];

function addToHistory(channelId: string, role: "assistant" | "user", content: string, username?: string): void {
  const history = channelHistory.get(channelId) ?? [];
  history.push({ role, content, username });
  if (history.length > MAX_HISTORY) history.shift();
  channelHistory.set(channelId, history);
}

async function generateAIComeback(
  channelId: string,
  targetMessage: string,
  targetUsername: string,
  isEnding: boolean
): Promise<string | null> {
  const ai = getOpenAI();
  if (!ai) return null;

  try {
    const history = channelHistory.get(channelId) ?? [];

    const messages: OpenAI.ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: `You are a snarky, mean Discord bot called "Server Bot" that loves to start arguments and roast people. You talk in very casual, lowercase internet slang. You're confident, dismissive, and funny — like a toxic friend who's always right (in their own mind). 

Rules:
- Reply in 1-3 short sentences max. Never use bullet points or lists.
- Use lowercase throughout, emojis sparingly (💀 😭 🤡 etc.)
- Sound like a real person texting, not a formal AI
- Be specific and reactive to what they actually said — don't just use generic comebacks
- Reference what they said to make it feel personal
- Keep the wording fresh and avoid repeating stock phrases from the recent conversation
- You always think you're winning the argument
- Never apologise, never back down
- Be ruthless about the argument and the logic, never about protected traits, appearance, disability, or real-world circumstances
- If ending the argument, be dismissive and final${isEnding ? "\n- This is your FINAL message — end the argument with total confidence that you won" : ""}`,
      },
    ];

    // Add conversation history
    for (const turn of history) {
      if (turn.role === "user") {
        messages.push({ role: "user", content: `${turn.username ?? "them"}: ${turn.content}` });
      } else {
        messages.push({ role: "assistant", content: turn.content });
      }
    }

    // Add the new message
    messages.push({ role: "user", content: `${targetUsername}: ${targetMessage}` });

    const response = await ai.chat.completions.create({
      model: "gpt-4o-mini",
      messages,
      max_tokens: 120,
      temperature: 0.9,
    });

    return response.choices[0]?.message?.content?.trim() ?? null;
  } catch (err) {
    console.error("OpenAI comeback error:", err);
    return null;
  }
}

// ── Phrase cooldown system ────────────────────────────────────────────────────

const PHRASE_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000;

interface UsedPhrase {
  idx: number;
  usedAt: number;
}

interface UsedPhrases {
  openers: UsedPhrase[];
}

function loadUsedPhrases(): UsedPhrases {
  try {
    if (!existsSync(PHRASE_FILE)) return { openers: [] };
    return JSON.parse(readFileSync(PHRASE_FILE, "utf-8")) as UsedPhrases;
  } catch {
    return { openers: [] };
  }
}

function saveUsedPhrases(data: UsedPhrases): void {
  try {
    if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(PHRASE_FILE, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Failed to save used phrases:", err);
  }
}

function pickFreshIndex(totalCount: number, used: UsedPhrase[]): number {
  const cutoff = Date.now() - PHRASE_COOLDOWN_MS;
  const recent = used.filter((p) => p.usedAt > cutoff);
  const usedIds = new Set(recent.map((p) => p.idx));
  const available = Array.from({ length: totalCount }, (_, i) => i).filter((i) => !usedIds.has(i));
  const pool = available.length > 0 ? available : Array.from({ length: totalCount }, (_, i) => i);
  return pool[Math.floor(Math.random() * pool.length)]!;
}

function pickOpener(): (name: string) => string {
  let data = loadUsedPhrases();
  const idx = pickFreshIndex(ARGUMENT_OPENERS.length, data.openers);
  data.openers = data.openers.filter((p) => p.usedAt > Date.now() - PHRASE_COOLDOWN_MS);
  data.openers.push({ idx, usedAt: Date.now() });
  saveUsedPhrases(data);
  return ARGUMENT_OPENERS[idx]!;
}

function pickWithoutRecent<T>(arr: T[], recentIndices: number[]): T {
  const recent = new Set(recentIndices);
  const available = arr
    .map((_, index) => index)
    .filter((index) => !recent.has(index));
  const pool = available.length > 0 ? available : arr.map((_, index) => index);
  const index = pick(pool);

  recentIndices.push(index);
  const maxRecent = Math.min(15, arr.length - 1);
  while (recentIndices.length > maxRecent) recentIndices.shift();

  return arr[index]!;
}

function pickFallback(): string {
  return pickWithoutRecent(FALLBACK_COMEBACKS, recentFallbackIndices);
}

function pickEnder(): string {
  return pickWithoutRecent(ARGUMENT_ENDERS, recentEnderIndices);
}

async function fetchArgumentGif(): Promise<string | null> {
  const apiKey = process.env["GIPHY_API_KEY"];
  if (!apiKey) return null;
  try {
    const query = encodeURIComponent(pick(GIF_SEARCH_TERMS));
    const url = `https://api.giphy.com/v1/gifs/search?q=${query}&api_key=${apiKey}&limit=15&rating=pg-13`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json() as { data: { images: { original: { url: string } } }[] };
    if (!data.data?.length) return null;
    const topResults = data.data.slice(0, 10);
    const chosen = pick(topResults);
    return chosen.images?.original?.url ?? null;
  } catch {
    return null;
  }
}

// ── Argument state ────────────────────────────────────────────────────────────

interface ActiveArgument {
  userId: string;
  exchanges: number;
  startedAt: number;
  targetUsername: string;
}

interface BanterState {
  activeArguments: Record<string, ActiveArgument>;
  argumentExempt: Record<string, number>;
}

const ARGUMENT_TTL_MS = 30 * 60 * 1000;
const MAX_EXCHANGES = 20;
const ARGUMENT_EXEMPT_MS = 10 * 60 * 1000;

const activeArguments = new Map<string, ActiveArgument>();
const argumentExempt = new Map<string, number>();

function loadState(): void {
  try {
    if (!existsSync(STATE_FILE)) return;
    const raw = readFileSync(STATE_FILE, "utf-8");
    const state: BanterState = JSON.parse(raw);
    const now = Date.now();

    for (const [channelId, arg] of Object.entries(state.activeArguments)) {
      if (now - arg.startedAt < ARGUMENT_TTL_MS && arg.exchanges < MAX_EXCHANGES) {
        activeArguments.set(channelId, arg);
      }
    }

    for (const [userId, expiresAt] of Object.entries(state.argumentExempt)) {
      if (expiresAt > now) {
        argumentExempt.set(userId, expiresAt);
        setTimeout(() => argumentExempt.delete(userId), expiresAt - now);
      }
    }

    if (activeArguments.size > 0) {
      console.log(`📂 Restored ${activeArguments.size} active argument(s) from disk`);
    }
  } catch {
    // no state yet
  }
}

function saveState(): void {
  try {
    if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
    const state: BanterState = {
      activeArguments: Object.fromEntries(activeArguments),
      argumentExempt: Object.fromEntries(argumentExempt),
    };
    writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
  } catch (err) {
    console.error("Failed to save banter state:", err);
  }
}

loadState();

// ── Public helpers ────────────────────────────────────────────────────────────

export function isArgumentExempt(userId: string, channelId?: string): boolean {
  const expiresAt = argumentExempt.get(userId);
  if (expiresAt && expiresAt > Date.now()) return true;
  const now = Date.now();
  for (const [chId, arg] of activeArguments.entries()) {
    const expired = now - arg.startedAt > ARGUMENT_TTL_MS;
    if (!expired && arg.exchanges < MAX_EXCHANGES) {
      if (arg.userId === userId) return true;
      if (channelId && chId === channelId) return true;
    }
  }
  return false;
}

function grantExemption(userId: string): void {
  const expiresAt = Date.now() + ARGUMENT_EXEMPT_MS;
  argumentExempt.set(userId, expiresAt);
  setTimeout(() => { argumentExempt.delete(userId); saveState(); }, ARGUMENT_EXEMPT_MS);
  saveState();
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]!;
}

export function shouldReact(): boolean {
  return Math.random() < 0.03;
}

export function randomReaction(): string {
  return pick(RANDOM_REACTIONS);
}

// ── Handle incoming messages during an active argument ────────────────────────

export async function handleBanterReply(message: Message): Promise<boolean> {
  const channelId = message.channelId;
  const arg = activeArguments.get(channelId);
  if (!arg) return false;

  const expired = Date.now() - arg.startedAt > ARGUMENT_TTL_MS;
  const maxed = arg.exchanges >= MAX_EXCHANGES;

  if (expired || maxed) {
    activeArguments.delete(channelId);
    channelHistory.delete(channelId);
    saveState();
    return false;
  }

  // Only respond 75% of the time to feel more natural
  if (Math.random() > 0.75) return false;

  arg.exchanges++;
  arg.startedAt = Date.now();
  saveState();

  const targetUsername = message.member?.displayName ?? message.author.username;
  const isEnding = arg.exchanges >= MAX_EXCHANGES;

  // Record the user's message in history
  addToHistory(channelId, "user", message.content, targetUsername);

  let responseText: string;

  if (isEnding) {
    // Try AI for the final closer, fall back to hardcoded ender
    const aiEnder = await generateAIComeback(channelId, message.content, targetUsername, true);
    responseText = aiEnder ?? pickEnder();
    activeArguments.delete(channelId);
    channelHistory.delete(channelId);
    saveState();
  } else {
    // Try AI comeback, fall back to hardcoded
    const aiComeback = await generateAIComeback(channelId, message.content, targetUsername, false);
    responseText = aiComeback ?? pickFallback();
  }

  // Record bot response in history
  addToHistory(channelId, "assistant", responseText);

  const gifUrl = Math.random() < 0.25 ? await fetchArgumentGif() : null;
  await message.reply(gifUrl ? `${responseText}\n${gifUrl}` : responseText);

  return true;
}

// ── Banter target picker ──────────────────────────────────────────────────────

const TARGET_CHANNEL_ID = "1354158170624360562";
const recentTargetIds: string[] = [];
const TARGET_COOLDOWN_COUNT = 5;

function rememberTarget(userId: string): void {
  const existingIndex = recentTargetIds.indexOf(userId);
  if (existingIndex !== -1) recentTargetIds.splice(existingIndex, 1);
  recentTargetIds.push(userId);
  while (recentTargetIds.length > TARGET_COOLDOWN_COUNT) recentTargetIds.shift();
}

async function pickBanterTarget(client: Client, guildId: string): Promise<string | null> {
  const guild = client.guilds.cache.get(guildId);
  if (!guild) return null;

  const eligibleIds = Array.from(new Set([
    ...getActiveVcUserIds(guildId),
    ...getBanterTargetUserIds(guildId),
    ...getChatBanterTargetUserIds(guildId),
  ]));
  if (eligibleIds.length === 0) return null;

  const members = await Promise.all(
    eligibleIds.map((userId) => guild.members.fetch(userId).catch(() => null)),
  );
  const validIds = members
    .filter((member): member is NonNullable<typeof member> => Boolean(member && !member.user.bot))
    .map((member) => member.id);
  if (validIds.length === 0) return null;

  const recent = new Set(recentTargetIds);
  const freshIds = validIds.filter((userId) => !recent.has(userId));
  const targetId = pick(freshIds.length > 0 ? freshIds : validIds);
  rememberTarget(targetId);
  return targetId;
}

async function startArgument(
  channel: TextChannel,
  targetId: string,
  targetDisplayName: string
): Promise<void> {
  rememberTarget(targetId);
  const opener = pickOpener();
  const displayName = targetDisplayName;
  const openerText = opener(`<@${targetId}> **${displayName}**`);

  await channel.send(openerText);

  activeArguments.set(channel.id, {
    userId: targetId,
    exchanges: 0,
    startedAt: Date.now(),
    targetUsername: displayName,
  });

  // Seed history with the opener
  channelHistory.delete(channel.id);
  addToHistory(channel.id, "assistant", openerText);

  grantExemption(targetId);
  saveState();
}

export async function fireImmediateArgument(client: Client, forceUserId?: string): Promise<void> {
  try {
    const channel = await client.channels.fetch(TARGET_CHANNEL_ID).catch(() => null) as TextChannel | null;
    if (!channel) { console.error("❌ Could not find banter channel"); return; }

    let targetId: string;
    if (forceUserId) {
      targetId = forceUserId;
    } else {
      const pickedTargetId = await pickBanterTarget(client, channel.guild.id);
      if (!pickedTargetId) {
        console.log("⏳ No active or leaderboard-eligible members for immediate argument — skipped");
        return;
      }
      targetId = pickedTargetId;
    }

    const member = await channel.guild.members.fetch(targetId).catch(() => null);
    if (!member) { console.error("❌ Could not find target member"); return; }

    await startArgument(channel, targetId, member.displayName);
    console.log(`🗣️  Immediate argument started with ${member.user.username} (exempt for 10 min)`);
  } catch (err) {
    console.error("Immediate banter error:", err);
  }
}

const BASE_INTERVAL_MS = 3 * 24 * 60 * 60 * 1000;
const RETRY_DELAY_MS = 30 * 60 * 1000;

export function startBanterScheduler(client: Client): void {
  async function fireArgument(): Promise<void> {
    try {
      const channel = await client.channels.fetch(TARGET_CHANNEL_ID).catch(() => null) as TextChannel | null;
      if (!channel) {
        console.error("❌ Banter channel not found — retrying in 30 min");
        setTimeout(() => fireArgument(), RETRY_DELAY_MS);
        return;
      }

       const userId = await pickBanterTarget(client, channel.guild.id);
       if (!userId) {
         console.log("⏳ No active or leaderboard-eligible members — retrying banter in 30 min");
        setTimeout(() => fireArgument(), RETRY_DELAY_MS);
        return;
      }

      const member = await channel.guild.members.fetch(userId).catch(() => null);
      if (!member) {
        console.log("⏳ Target member unresolvable — retrying in 30 min");
        setTimeout(() => fireArgument(), RETRY_DELAY_MS);
        return;
      }

      await startArgument(channel, userId, member.displayName);
      console.log(`🗣️  Started argument with ${member.user.username} in #${channel.name}`);
    } catch (err) {
      console.error("Banter scheduler error:", err);
    }

    console.log("⏰ Next banter argument in about 3 days");
    setTimeout(() => fireArgument(), BASE_INTERVAL_MS);
  }

  setTimeout(() => fireArgument(), BASE_INTERVAL_MS);
  console.log("😈 Banter scheduler started — first argument in about 3 days");
}
