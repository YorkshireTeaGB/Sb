import { VoiceState, Client, ChannelType, VoiceChannel, TextChannel } from "discord.js";
import { addSeconds } from "../store/vcStats.js";
import { addCoins } from "../store/coins.js";

interface VcSession {
  guildId: string;
  joinedAt: number;
}

const vcSessions = new Map<string, VcSession>();
const coinCheckStart = new Map<string, number>();

export const TRACKED_VOICE_CHANNEL_ID = "872289832066482262";

const COIN_CHANNEL_ID = "1512995703956439241";
const COIN_CHANCE = 0.1;
const COIN_INTERVAL_MS = 60 * 60 * 1000;
const COIN_CHECK_EVERY_MS = 5 * 60 * 1000;

function finalizeSession(userId: string): void {
  const session = vcSessions.get(userId);
  if (!session) return;
  const elapsed = Math.floor((Date.now() - session.joinedAt) / 1000);
  if (elapsed > 0) {
    addSeconds(session.guildId, userId, elapsed);
  }
  vcSessions.delete(userId);
}

export function handleVoiceStateUpdate(
  oldState: VoiceState,
  newState: VoiceState
): void {
  const userId = newState.member?.user.id ?? oldState.member?.user.id;
  if (!userId) return;
  // Bot voice connections are operational only and never count as VC time or coin eligibility.
  if (newState.member?.user.bot || oldState.member?.user.bot) return;

  const guildId = newState.guild.id;

  const leftChannel = !newState.channelId && oldState.channelId;
  const joinedChannel = newState.channelId && !oldState.channelId;
  const changedChannel =
    newState.channelId &&
    oldState.channelId &&
    newState.channelId !== oldState.channelId;

  if (leftChannel) {
    finalizeSession(userId);
    coinCheckStart.delete(userId);
    return;
  }

  if (joinedChannel || changedChannel) {
    const newChannelId = newState.channelId!;

    if (changedChannel && vcSessions.has(userId)) {
      finalizeSession(userId);
      coinCheckStart.delete(userId);
    }

    if (newChannelId !== TRACKED_VOICE_CHANNEL_ID) {
      console.log(
        `?? ${newState.member?.user.username} joined "${newState.channel?.name}" � not the tracked channel, skipping`
      );
      return;
    }

    vcSessions.set(userId, { guildId, joinedAt: Date.now() });
    coinCheckStart.set(userId, Date.now());
    console.log(
      `?? ${newState.member?.user.username} joined the tracked VC � tracking time + coin rolls`
    );
    return;
  }

}

export function startCoinInterval(client: Client): void {
  setInterval(async () => {
    const now = Date.now();

    for (const [userId, sessionStart] of coinCheckStart.entries()) {
      const elapsed = now - sessionStart;
      const fullHours = Math.floor(elapsed / COIN_INTERVAL_MS);
      if (fullHours < 1) continue;

      coinCheckStart.set(userId, sessionStart + fullHours * COIN_INTERVAL_MS);

      for (let i = 0; i < fullHours; i++) {
        if (Math.random() >= COIN_CHANCE) continue;

        addCoins(userId, 1);
        console.log(`?? VC coin awarded to ${userId} (10% roll)`);

        try {
          const channel = await client.channels.fetch(COIN_CHANNEL_ID).catch(() => null);
          if (channel && channel.isTextBased() && "send" in channel) {
            const messages = [
              `?? <@${userId}> just got lucky and earned a coin for chilling in VC!`,
              `?? <@${userId}> has been blessed � a free coin for hanging out in voice!`,
              `?? The RNG gods smiled on <@${userId}> � they just earned a coin in VC!`,
              `?? <@${userId}> keeps it real and picks up a free coin for being in voice!`,
              `? <@${userId}> was vibing in VC long enough to snag a coin!`,
            ];
            const msg = messages[Math.floor(Math.random() * messages.length)]!;
            await (channel as TextChannel).send(msg);
          }
        } catch (err) {
          console.error("Coin announcement error:", err);
        }
      }
    }
  }, COIN_CHECK_EVERY_MS);

  console.log(
    `?? Hourly VC coin rolls active � only counting channel ${TRACKED_VOICE_CHANNEL_ID}`
  );
}

export function getLiveSeconds(guildId: string, userId: string): number {
  const session = vcSessions.get(userId);
  if (!session || session.guildId !== guildId) return 0;
  return Math.floor((Date.now() - session.joinedAt) / 1000);
}

export function getActiveVcUserIds(guildId?: string): string[] {
  const ids: string[] = [];
  for (const [userId, session] of vcSessions.entries()) {
    if (!guildId || session.guildId === guildId) {
      ids.push(userId);
    }
  }
  return ids;
}

export function initializeVoiceSessions(client: Client): void {
  let count = 0;
  for (const guild of client.guilds.cache.values()) {
    const vc = guild.channels.cache.get(TRACKED_VOICE_CHANNEL_ID) as VoiceChannel | undefined;
    if (!vc) continue;
    for (const [userId, member] of vc.members) {
      // Keep this defensive check even though the AFK monitor's connection is a bot.
      if (member.user.bot) continue;
      vcSessions.set(userId, { guildId: guild.id, joinedAt: Date.now() });
      coinCheckStart.set(userId, Date.now());
      count++;
    }
  }
  if (count > 0) {
    console.log(`?? Found ${count} member(s) already in tracked VC � started tracking`);
  }
}
