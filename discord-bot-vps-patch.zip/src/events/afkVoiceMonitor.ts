import {
  ChannelType,
  Client,
  Events,
  Guild,
  PermissionFlagsBits,
  VoiceChannel,
  VoiceState,
} from "discord.js";
import {
  getVoiceConnection,
  joinVoiceChannel,
  VoiceConnection,
  VoiceConnectionStatus,
} from "@discordjs/voice";
import { TRACKED_VOICE_CHANNEL_ID } from "./voiceStateUpdate.js";

const INACTIVITY_LIMIT_MS = 45 * 60 * 1000;
const CHECK_INTERVAL_MS = 30 * 1000;

interface AfkMonitor {
  guild: Guild;
  channel: VoiceChannel;
  ready: boolean;
}

const monitors = new Map<string, AfkMonitor>();
const lastVoiceActivity = new Map<string, Map<string, number>>();
const attachedConnections = new WeakSet<VoiceConnection>();
const warningsShown = new Set<string>();
let checkTimer: NodeJS.Timeout | undefined;

function getTrackedChannel(guild: Guild): VoiceChannel | null {
  const channel = guild.channels.cache.get(TRACKED_VOICE_CHANNEL_ID);
  return channel?.type === ChannelType.GuildVoice ? channel : null;
}

function getAfkChannel(guild: Guild): VoiceChannel | null {
  const configuredName = (process.env["AFK_CHANNEL_NAME"] ?? "afk").toLowerCase();
  return guild.channels.cache.find(
    (channel): channel is VoiceChannel =>
      channel.type === ChannelType.GuildVoice &&
      channel.name.toLowerCase() === configuredName,
  ) ?? null;
}

function getActivityMap(guildId: string): Map<string, number> {
  let activity = lastVoiceActivity.get(guildId);
  if (!activity) {
    activity = new Map<string, number>();
    lastVoiceActivity.set(guildId, activity);
  }
  return activity;
}

function warnOnce(key: string, message: string): void {
  if (warningsShown.has(key)) return;
  warningsShown.add(key);
  console.warn(message);
}

function seedCurrentMembers(monitor: AfkMonitor): void {
  const activity = getActivityMap(monitor.guild.id);
  const now = Date.now();
  activity.clear();
  for (const [userId, member] of monitor.channel.members) {
    if (!member.user.bot) activity.set(userId, now);
  }
}

function attachReceiver(monitor: AfkMonitor, connection: VoiceConnection): void {
  if (attachedConnections.has(connection)) return;
  attachedConnections.add(connection);

  connection.receiver.speaking.on("start", (userId) => {
    const member = monitor.guild.members.cache.get(userId);
    if (!member || member.user.bot || member.voice.channelId !== monitor.channel.id) return;
    getActivityMap(monitor.guild.id).set(userId, Date.now());
  });

  connection.on("stateChange", (_oldState, newState) => {
    const ready =
      newState.status === VoiceConnectionStatus.Ready &&
      connection.joinConfig.channelId === monitor.channel.id;
    if (ready && !monitor.ready) seedCurrentMembers(monitor);
    monitor.ready = ready;
  });

  connection.on("error", (error) => {
    console.error(`AFK voice monitor connection error in guild ${monitor.guild.id}:`, error);
  });
}

function ensureConnection(monitor: AfkMonitor): VoiceConnection | null {
  const botMember = monitor.guild.members.me;
  if (!botMember) return null;

  const permissions = monitor.channel.permissionsFor(botMember);
  if (!permissions?.has(PermissionFlagsBits.Connect)) {
    monitor.ready = false;
    warnOnce(
      `connect:${monitor.guild.id}`,
      `AFK voice monitor needs Connect permission in ${monitor.channel.name}.`,
    );
    return null;
  }

  const currentConnection = getVoiceConnection(monitor.guild.id);
  let connection: VoiceConnection;
  if (
    currentConnection &&
    currentConnection.state.status !== VoiceConnectionStatus.Destroyed &&
    currentConnection.joinConfig.channelId === monitor.channel.id
  ) {
    connection =
      currentConnection.state.status === VoiceConnectionStatus.Disconnected
        ? joinVoiceChannel({
            channelId: monitor.channel.id,
            guildId: monitor.guild.id,
            adapterCreator: monitor.guild.voiceAdapterCreator,
            selfDeaf: false,
            selfMute: true,
          })
        : currentConnection;
  } else {
    if (
      currentConnection &&
      currentConnection.state.status !== VoiceConnectionStatus.Destroyed
    ) {
      currentConnection.destroy();
    }
    connection = joinVoiceChannel({
      channelId: monitor.channel.id,
      guildId: monitor.guild.id,
      adapterCreator: monitor.guild.voiceAdapterCreator,
      selfDeaf: false,
      selfMute: true,
    });
  }
  attachReceiver(monitor, connection);

  const ready =
    connection.state.status === VoiceConnectionStatus.Ready &&
    connection.joinConfig.channelId === monitor.channel.id;
  if (ready && !monitor.ready) seedCurrentMembers(monitor);
  monitor.ready = ready;
  return connection;
}

function disconnectIfEmpty(monitor: AfkMonitor): boolean {
  const humansPresent = [...monitor.channel.members.values()].some((member) => !member.user.bot);
  if (humansPresent) return false;

  const connection = getVoiceConnection(monitor.guild.id);
  if (
    connection &&
    connection.state.status !== VoiceConnectionStatus.Destroyed &&
    connection.joinConfig.channelId === monitor.channel.id
  ) {
    connection.destroy();
  }
  monitor.ready = false;
  getActivityMap(monitor.guild.id).clear();
  return true;
}

export function handleAfkVoiceStateUpdate(oldState: VoiceState, newState: VoiceState): void {
  const monitor = monitors.get(newState.guild.id);
  if (!monitor) return;

  const member = newState.member ?? oldState.member;
  if (!member || member.user.bot) return;

  const wasInTrackedChannel = oldState.channelId === monitor.channel.id;
  const isInTrackedChannel = newState.channelId === monitor.channel.id;

  if (!wasInTrackedChannel && isInTrackedChannel) {
    getActivityMap(monitor.guild.id).set(member.id, Date.now());
    ensureConnection(monitor);
  } else if (wasInTrackedChannel && !isInTrackedChannel) {
    getActivityMap(monitor.guild.id).delete(member.id);
    disconnectIfEmpty(monitor);
  }
}

async function checkMonitor(monitor: AfkMonitor): Promise<void> {
  if (disconnectIfEmpty(monitor)) return;

  const activeConnection = ensureConnection(monitor);
  if (
    !activeConnection ||
    activeConnection.state.status !== VoiceConnectionStatus.Ready ||
    activeConnection.joinConfig.channelId !== monitor.channel.id
  ) {
    monitor.ready = false;
    return;
  }

  if (!monitor.ready) seedCurrentMembers(monitor);
  monitor.ready = true;

  const activity = getActivityMap(monitor.guild.id);
  const now = Date.now();

  // Keep long speaking sessions fresh; start events alone fire only once per utterance.
  for (const userId of activeConnection.receiver.speaking.users.keys()) {
    const member = monitor.channel.members.get(userId);
    if (member && !member.user.bot) activity.set(userId, now);
  }

  const afkChannel = getAfkChannel(monitor.guild);
  if (!afkChannel || afkChannel.id === monitor.channel.id) {
    warnOnce(
      `afk-channel:${monitor.guild.id}`,
      `AFK voice monitor could not find a distinct voice channel named ${process.env["AFK_CHANNEL_NAME"] ?? "afk"} in guild ${monitor.guild.id}.`,
    );
    return;
  }

  const botMember = monitor.guild.members.me;
  const canMove =
    !!botMember &&
    monitor.channel.permissionsFor(botMember)?.has(PermissionFlagsBits.MoveMembers) === true &&
    afkChannel.permissionsFor(botMember)?.has(PermissionFlagsBits.MoveMembers) === true;
  if (!canMove) {
    warnOnce(
      `move-members:${monitor.guild.id}`,
      `AFK voice monitor needs Move Members permission in ${monitor.channel.name} and ${afkChannel.name}.`,
    );
    return;
  }

  for (const [userId, lastActiveAt] of activity.entries()) {
    const member = monitor.channel.members.get(userId);
    if (!member || member.user.bot) {
      activity.delete(userId);
      continue;
    }
    if (activeConnection.receiver.speaking.users.has(userId)) {
      activity.set(userId, now);
      continue;
    }
    if (now - lastActiveAt < INACTIVITY_LIMIT_MS) continue;

    try {
      await member.voice.setChannel(
        afkChannel,
        "Moved after 45 minutes without detected voice activity",
      );
      activity.delete(userId);
      console.info(`Moved inactive member ${userId} to the AFK voice channel.`);
    } catch (error) {
      activity.set(userId, Date.now());
      console.error(`Failed to move inactive member ${userId} to AFK:`, error);
    }
  }
}

export function startAfkVoiceMonitor(client: Client): void {
  if (checkTimer) return;

  for (const guild of client.guilds.cache.values()) {
    const channel = getTrackedChannel(guild);
    if (!channel) continue;

    const monitor: AfkMonitor = { guild, channel, ready: false };
    monitors.set(guild.id, monitor);
    seedCurrentMembers(monitor);
    if ([...channel.members.values()].some((member) => !member.user.bot)) {
      ensureConnection(monitor);
    }
  }

  checkTimer = setInterval(() => {
    for (const monitor of monitors.values()) {
      void checkMonitor(monitor).catch((error) => {
        console.error(`AFK voice monitor failed in guild ${monitor.guild.id}:`, error);
      });
    }
  }, CHECK_INTERVAL_MS);
}
