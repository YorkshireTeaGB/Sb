import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  ButtonInteraction,
  StringSelectMenuInteraction,
  UserSelectMenuInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  UserSelectMenuBuilder,
  MessageFlags,
} from "discord.js";
import { getInventory, removeItem, addItem } from "../store/inventory.js";

const ADMIN_ID = "463733669304074240";

const ITEM_INFO: Record<string, { name: string; emoji: string }> = {
  timeout_10s:        { name: "Timeout (1m)",            emoji: "☠️"  },
  server_mute_10s:    { name: "Server Mute (40s)",       emoji: "🔇"  },
  server_deafen_10s:  { name: "Server Deafen (30s)",     emoji: "🔕"  },
  move_to_afk:        { name: "Move to AFK",             emoji: "🚀"  },
  text_channel_lock:  { name: "Text Channel Lock (30m)", emoji: "🔒"  },
  voice_channel_lock: { name: "Voice Channel Lock (1h)", emoji: "🔈"  },
  set_nickname:       { name: "Set Nickname",            emoji: "✏️"  },
};

const ALL_ITEM_IDS = Object.keys(ITEM_INFO);

export const seeInventoryCommand = new SlashCommandBuilder()
  .setName("seeinventory")
  .setDescription("Admin: view and manage a user's shop inventory");

export async function seeInventoryExecute(interaction: ChatInputCommandInteraction): Promise<void> {
  if (interaction.user.id !== ADMIN_ID) {
    await interaction.reply({ content: "You don't have permission to use this command.", flags: MessageFlags.Ephemeral });
    return;
  }
  await interaction.reply({
    embeds: [rootEmbed()],
    components: [userSelectRow()],
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleAdminInvInteraction(
  interaction: ButtonInteraction | StringSelectMenuInteraction | UserSelectMenuInteraction
): Promise<void> {
  if (interaction.user.id !== ADMIN_ID) return;

  try {
    if (interaction.isUserSelectMenu() && interaction.customId === "admin_inv_usel") {
      await handleUserSelect(interaction);
      return;
    }

    if (interaction.isStringSelectMenu()) {
      if (interaction.customId.startsWith("admin_inv_isel_")) {
        await handleItemSelect(interaction);
        return;
      }
      if (interaction.customId.startsWith("admin_inv_givesel_")) {
        await handleGiveItemSelect(interaction);
        return;
      }
    }

    if (interaction.isButton()) {
      if (interaction.customId === "admin_inv_back") {
        await interaction.update({ embeds: [rootEmbed()], components: [userSelectRow()] });
        return;
      }
      if (interaction.customId.startsWith("admin_inv_give_")) {
        const userId = interaction.customId.replace("admin_inv_give_", "");
        await showGiveMenu(interaction, userId);
        return;
      }
      if (interaction.customId.startsWith("admin_inv_confirm_")) {
        await handleConfirm(interaction);
        return;
      }
      if (interaction.customId.startsWith("admin_inv_giveconfirm_")) {
        await handleGiveConfirm(interaction);
        return;
      }
      if (interaction.customId.startsWith("admin_inv_cancel_")) {
        const userId = interaction.customId.replace("admin_inv_cancel_", "");
        await showInventory(interaction, userId);
        return;
      }
    }
  } catch (err) {
    console.error("Admin inventory interaction error:", err);
  }
}

function rootEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle("🎒 Inventory Manager")
    .setDescription("Select a user below to view and manage their shop items.");
}

function userSelectRow(): ActionRowBuilder<UserSelectMenuBuilder> {
  return new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(
    new UserSelectMenuBuilder().setCustomId("admin_inv_usel").setPlaceholder("Select a user...")
  );
}

function backRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("admin_inv_back").setLabel("← Back").setStyle(ButtonStyle.Secondary)
  );
}

async function resolveDisplayName(
  interaction: ButtonInteraction | StringSelectMenuInteraction | UserSelectMenuInteraction,
  userId: string
): Promise<string> {
  const member = interaction.guild
    ? await interaction.guild.members.fetch(userId).catch(() => null)
    : null;
  if (member) return member.displayName;
  const user = await interaction.client.users.fetch(userId).catch(() => null);
  return user?.username ?? userId;
}

async function handleUserSelect(interaction: UserSelectMenuInteraction): Promise<void> {
  const userId = interaction.values[0]!;
  await showInventory(interaction, userId);
}

async function showInventory(
  interaction: ButtonInteraction | UserSelectMenuInteraction | StringSelectMenuInteraction,
  userId: string,
  banner?: string
): Promise<void> {
  await interaction.deferUpdate();
  const displayName = await resolveDisplayName(interaction, userId);
  const inventory = getInventory(userId);
  const entries = Object.entries(inventory).filter(([, c]) => c > 0);
  const soundboardItemIds = entries
    .map(([id]) => /^soundboard_(\d+)_(\d+)$/.exec(id))
    .filter((match): match is RegExpExecArray => match !== null);
  const soundNames = new Map<string, string>();
  if (interaction.guild && soundboardItemIds.some((match) => match[1] === interaction.guild!.id)) {
    const sounds = await interaction.guild.soundboardSounds.fetch().catch(() => null);
    for (const sound of sounds?.values() ?? []) soundNames.set(sound.soundId, sound.name);
  }

  const getItemInfo = (id: string): { name: string; emoji: string } => {
    const soundboardItem = /^soundboard_(\d+)_(\d+)$/.exec(id);
    if (!soundboardItem) return ITEM_INFO[id] ?? { name: id, emoji: "📦" };
    if (soundboardItem[1] === interaction.guild?.id) {
      return { name: soundNames.get(soundboardItem[2]!) ?? "Unavailable sound", emoji: "🔊" };
    }
    return { name: "Soundboard play (another server)", emoji: "🔊" };
  };

  const giveButton = new ButtonBuilder()
    .setCustomId(`admin_inv_give_${userId}`)
    .setLabel("Give Item")
    .setEmoji("🎁")
    .setStyle(ButtonStyle.Success);

  const backBtn = new ButtonBuilder()
    .setCustomId("admin_inv_back")
    .setLabel("← Back")
    .setStyle(ButtonStyle.Secondary);

  const actionRow = new ActionRowBuilder<ButtonBuilder>().addComponents(giveButton, backBtn);

  if (entries.length === 0) {
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xffd700)
          .setTitle(`🎒 ${displayName}'s Inventory`)
          .setDescription(`${banner ? banner + "\n\n" : ""}This user has no items.`),
      ],
      components: [actionRow],
    });
    return;
  }

  const lines = entries.map(([id, count]) => {
    const info = getItemInfo(id);
    return `${info.emoji} **${info.name}** — ×${count}`;
  });

  const removeOptions = entries.map(([id, count]) => {
    const info = getItemInfo(id);
    return new StringSelectMenuOptionBuilder()
      .setValue(id)
      .setLabel(`${info.emoji} ${info.name} ×${count}`.slice(0, 100));
  });

  const removeRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`admin_inv_isel_${userId}`)
      .setPlaceholder("Select an item to remove...")
      .addOptions(removeOptions)
  );

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle(`🎒 ${displayName}'s Inventory`)
        .setDescription(`${banner ? banner + "\n\n" : ""}${lines.join("\n")}`)
        .setFooter({ text: "Use the dropdown to remove an item, or Give Item to add one." }),
    ],
    components: [removeRow, actionRow],
  });
}

async function showGiveMenu(interaction: ButtonInteraction, userId: string): Promise<void> {
  const displayName = await resolveDisplayName(interaction, userId);

  const options = ALL_ITEM_IDS.map((id) => {
    const info = ITEM_INFO[id]!;
    return new StringSelectMenuOptionBuilder().setValue(id).setLabel(`${info.emoji} ${info.name}`);
  });

  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`admin_inv_givesel_${userId}`)
      .setPlaceholder("Choose an item to give...")
      .addOptions(options)
  );

  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setColor(0x57f287)
        .setTitle(`🎁 Give Item to ${displayName}`)
        .setDescription("Select which item to give them."),
    ],
    components: [selectRow, backRow()],
  });
}

async function handleGiveItemSelect(interaction: StringSelectMenuInteraction): Promise<void> {
  const userId = interaction.customId.replace("admin_inv_givesel_", "");
  const itemId = interaction.values[0]!;
  const info = ITEM_INFO[itemId];
  const displayName = await resolveDisplayName(interaction, userId);

  const confirmRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`admin_inv_giveconfirm_${userId}_${itemId}`)
      .setLabel("Give 1")
      .setEmoji("🎁")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`admin_inv_cancel_${userId}`)
      .setLabel("Cancel")
      .setStyle(ButtonStyle.Secondary)
  );

  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setColor(0x57f287)
        .setTitle("✅ Confirm Give")
        .setDescription(`Give **1× ${info?.emoji ?? ""} ${info?.name ?? itemId}** to **${displayName}**?`),
    ],
    components: [confirmRow],
  });
}

async function handleGiveConfirm(interaction: ButtonInteraction): Promise<void> {
  const content = interaction.customId.replace("admin_inv_giveconfirm_", "");
  const match = content.match(/^(\d+)_(.+)$/);
  if (!match) return;
  const userId = match[1]!;
  const itemId = match[2]!;

  const info = ITEM_INFO[itemId];
  const displayName = await resolveDisplayName(interaction, userId);
  addItem(userId, itemId);

  const banner = `✅ Gave **1× ${info?.emoji ?? ""} ${info?.name ?? itemId}** to **${displayName}**.`;
  await showInventory(interaction, userId, banner);
}

async function handleItemSelect(interaction: StringSelectMenuInteraction): Promise<void> {
  const userId = interaction.customId.replace("admin_inv_isel_", "");
  const itemId = interaction.values[0]!;
  const info = ITEM_INFO[itemId];
  const displayName = await resolveDisplayName(interaction, userId);
  const inventory = getInventory(userId);
  const count = inventory[itemId] ?? 0;

  const confirmRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`admin_inv_confirm_${userId}_${itemId}`)
      .setLabel("Remove 1")
      .setEmoji("🗑️")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(`admin_inv_cancel_${userId}`)
      .setLabel("Cancel")
      .setStyle(ButtonStyle.Secondary)
  );

  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setColor(0xff6b6b)
        .setTitle("⚠️ Confirm Removal")
        .setDescription(
          `Remove **1× ${info?.emoji ?? ""} ${info?.name ?? itemId}** from **${displayName}**?\n\nThey currently have **×${count}**.`
        ),
    ],
    components: [confirmRow],
  });
}

async function handleConfirm(interaction: ButtonInteraction): Promise<void> {
  const content = interaction.customId.replace("admin_inv_confirm_", "");
  const match = content.match(/^(\d+)_(.+)$/);
  if (!match) return;
  const userId = match[1]!;
  const itemId = match[2]!;

  const info = ITEM_INFO[itemId];
  const displayName = await resolveDisplayName(interaction, userId);
  const removed = removeItem(userId, itemId);

  if (!removed) {
    await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setColor(0xff6b6b)
          .setTitle("❌ Not Found")
          .setDescription(`**${displayName}** didn't have that item.`),
      ],
      components: [backRow()],
    });
    return;
  }

  const banner = `✅ Removed **1× ${info?.emoji ?? ""} ${info?.name ?? itemId}** from **${displayName}**.`;
  await showInventory(interaction, userId, banner);
}
