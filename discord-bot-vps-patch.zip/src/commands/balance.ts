import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  MessageFlags,
} from "discord.js";
import { getBalance, getAllBalances } from "../store/coins.js";

export const balanceCommand = new SlashCommandBuilder()
  .setName("balance")
  .setDescription("Check your coin balance or see the richest members");

export async function balanceExecute(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!interaction.guild) {
    await interaction.reply({ content: "This command can only be used in a server.", flags: MessageFlags.Ephemeral });
    return;
  }

  await interaction.deferReply();

  const userId = interaction.user.id;
  const myBalance = getBalance(userId);
  const allBalances = getAllBalances();

  const sorted = Object.entries(allBalances)
    .filter(([uid, coins]) =>
      coins > 0 &&
      uid !== interaction.client.user?.id &&
      interaction.guild!.members.cache.get(uid)?.user.bot !== true
    )
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  const leaderboardRows = await Promise.all(
    sorted.map(async ([uid, coins], i) => {
      const member = await interaction.guild!.members.fetch(uid).catch(() => null);
      const name = member?.displayName ?? `<@${uid}>`;
      return `**${i + 1}.** ${name} — **${coins} coin${coins === 1 ? "" : "s"}**`;
    })
  );

  const embed = new EmbedBuilder()
    .setColor(0xffd700)
    .setTitle("💰 Coin Balance")
    .addFields({ name: "Your Balance", value: `**${myBalance} coin${myBalance === 1 ? "" : "s"}**` });

  if (leaderboardRows.length > 0) {
    embed.addFields({ name: "🏆 Most Coins", value: leaderboardRows.join("\n") });
  }

  await interaction.editReply({ embeds: [embed] });
}
