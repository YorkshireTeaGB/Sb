import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  ButtonInteraction,
  StringSelectMenuInteraction,
  UserSelectMenuInteraction,
  ModalSubmitInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  UserSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionFlagsBits,
  ChannelType,
  VoiceChannel,
  TextChannel,
  Guild,
  GuildMember,
  MessageFlags,
} from "discord.js";
import { getBalance, spendCoins, addCoins } from "../store/coins.js";
import { setNicknameLock, removeNicknameLock, hasNicknameLock, getNicknameLock } from "../store/nicknameLock.js";
import { addItem, getInventory, removeItem, hasItem } from "../store/inventory.js";

const UNLOCK_NICKNAME_COST = 12;
const TEXT_LOCK_CHANNEL_ID = "1354158170624360562";
const VOICE_LOCK_CHANNEL_ID = "872289832066482262";
const SOUNDBOARD_ITEM_COST = 1;
const SOUNDBOARD_ITEM_PREFIX = "soundboard_";
const SOUNDBOARD_PAGE_SIZE = 25;

const unoReverseCards = new Map<string, ReturnType<typeof setTimeout>>();

function activateUnoReverse(userId: string): void {
  const existing = unoReverseCards.get(userId);
  if (existing) clearTimeout(existing);
  const timer = setTimeout(() => { unoReverseCards.delete(userId); }, 12 * 60 * 60 * 1000);
  unoReverseCards.set(userId, timer);
}

function hasUnoReverse(userId: string): boolean {
  return unoReverseCards.has(userId);
}

function consumeUnoReverse(userId: string): void {
  const timer = unoReverseCards.get(userId);
  if (timer) clearTimeout(timer);
  unoReverseCards.delete(userId);
}

export const SHOP_ITEMS: Record<string, {
  name: string; emoji: string; cost: number; description: string;
  needsVoice: boolean; needsNickname: boolean;
}> = {
  timeout_10s:       { name: "Timeout (1m)",               emoji: "☠️", cost: 8,  description: "Times someone out for 1 minute",                                             needsVoice: false, needsNickname: false },
  server_mute_10s:   { name: "Server Mute (40s)",          emoji: "🔇", cost: 6,  description: "Server mutes someone in VC for 40 seconds",                                  needsVoice: true,  needsNickname: false },
  server_deafen_10s: { name: "Server Deafen (30s)",        emoji: "🔕", cost: 8,  description: "Server deafens someone in VC for 30 seconds",                                needsVoice: true,  needsNickname: false },
  move_to_afk:       { name: "Move to AFK",                emoji: "🚀", cost: 3,  description: "Boots someone to the AFK channel",                                           needsVoice: true,  needsNickname: false },
  text_channel_lock: { name: "Text Channel Lock (30m)",    emoji: "🔒", cost: 12, description: "Locks someone out of the text channel for 30 minutes",                       needsVoice: false, needsNickname: false },
  voice_channel_lock:{ name: "Voice Channel Lock (1h)",   emoji: "🔈", cost: 30, description: "Locks someone out of the voice channel for 1 hour",                          needsVoice: false, needsNickname: false },
  uno_reverse:       { name: "UNO Reverse",                emoji: "🔄", cost: 12, description: "Passive: reverses the next item used on you back onto the attacker (12h)", needsVoice: false, needsNickname: false },
  set_nickname:      { name: "Set Nickname",               emoji: "✏️", cost: 10, description: "Lock someone's nickname to anything you want",                               needsVoice: false, needsNickname: true  },
};

function mainEmbed(balance: number): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xffd700)
    .setTitle("🛒 Server Shop")
    .setDescription("Spend your coins on chaos.")
    .addFields({ name: "💰 Your Balance", value: `**${balance} coin${balance === 1 ? "" : "s"}**` })
    .setFooter({ text: "Earn coins by finishing top 3 in the weekly VC leaderboard" });
}

function mainButtons(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("shop_open_buy").setLabel("Buy Item").setEmoji("🛒").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("shop_open_use").setLabel("Use Items").setEmoji("🎒").setStyle(ButtonStyle.Success),
  );
}

function backButton(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("shop_back").setLabel("Back").setEmoji("◀️").setStyle(ButtonStyle.Secondary),
  );
}

function soundboardInventoryId(guildId: string, soundId: string): string {
  return `${SOUNDBOARD_ITEM_PREFIX}${guildId}_${soundId}`;
}

function parseSoundboardInventoryId(itemId: string): { guildId: string; soundId: string } | null {
  const match = /^soundboard_(\d+)_(\d+)$/.exec(itemId);
  return match ? { guildId: match[1]!, soundId: match[2]! } : null;
}

async function showSoundboardShop(
  interaction: ButtonInteraction | StringSelectMenuInteraction,
  requestedPage = 0,
): Promise<void> {
  const guild = interaction.guild;
  if (!guild) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Server Only").setDescription("Soundboard sounds are available in a server shop.")],
      components: [backButton()],
    });
    return;
  }

  await interaction.deferUpdate();
  let sounds;
  try {
    sounds = await guild.soundboardSounds.fetch();
  } catch (error) {
    console.error("Failed to fetch guild soundboard sounds:", error);
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Couldn't Load Sounds").setDescription("I couldn't load this server's soundboard. Check my permissions and try again.")],
      components: [backButton()],
    });
    return;
  }

  const soundList = [...sounds.values()];
  if (soundList.length === 0) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("🔊 Server Soundboard").setDescription("This server doesn't have any custom soundboard sounds to buy.")],
      components: [backButton()],
    });
    return;
  }

  const pageCount = Math.ceil(soundList.length / SOUNDBOARD_PAGE_SIZE);
  const page = Math.max(0, Math.min(Math.floor(requestedPage), pageCount - 1));
  const pageSounds = soundList.slice(page * SOUNDBOARD_PAGE_SIZE, (page + 1) * SOUNDBOARD_PAGE_SIZE);
  const soundOptions = pageSounds.map((sound) =>
    new StringSelectMenuOptionBuilder()
      .setValue(sound.soundId)
      .setLabel(`🔊 ${sound.name}`.slice(0, 100))
      .setDescription(`One play · ${SOUNDBOARD_ITEM_COST} coin`)
  );
  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`shop_soundboard_select_${page}`)
      .setPlaceholder("Choose a sound to buy...")
      .addOptions(soundOptions)
  );
  const rows = [selectRow] as ActionRowBuilder<any>[];

  if (pageCount > 1) {
    const pageButtons = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`shop_soundboard_page_${page - 1}`)
        .setLabel("Previous")
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(page === 0),
      new ButtonBuilder()
        .setCustomId(`shop_soundboard_page_${page + 1}`)
        .setLabel("Next")
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(page === pageCount - 1),
    );
    rows.push(pageButtons);
  }
  rows.push(backButton());

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(0x1db954)
        .setTitle("🔊 Server Soundboard")
        .setDescription(`Each sound costs **${SOUNDBOARD_ITEM_COST} coin** and gives you one play. Buy another whenever you want to play it again.`)
        .addFields({ name: "Your Balance", value: `**${getBalance(interaction.user.id)} coins**` })
        .setFooter({ text: `Page ${page + 1} of ${pageCount}` }),
    ],
    components: rows,
  });
}

async function showSoundboardPurchaseConfirmation(
  interaction: StringSelectMenuInteraction,
  soundId: string,
): Promise<void> {
  const guild = interaction.guild;
  if (!guild) {
    await interaction.update({ content: "Soundboard sounds can only be bought in a server.", embeds: [], components: [backButton()] });
    return;
  }

  await interaction.deferUpdate();
  const sound = await guild.soundboardSounds.fetch(soundId).catch(() => null);
  if (!sound) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Sound Not Found").setDescription("That sound is no longer available.")],
      components: [backButton()],
    });
    return;
  }

  const balance = getBalance(interaction.user.id);
  const confirmRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`shop_confirm_soundboard_${sound.soundId}`)
      .setLabel(`Buy one play for ${SOUNDBOARD_ITEM_COST} coin`)
      .setEmoji("✅")
      .setStyle(ButtonStyle.Success)
      .setDisabled(balance < SOUNDBOARD_ITEM_COST),
    new ButtonBuilder().setCustomId("shop_back").setLabel("Cancel").setStyle(ButtonStyle.Secondary),
  );

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(balance >= SOUNDBOARD_ITEM_COST ? 0x1db954 : 0xff6b6b)
        .setTitle(`🔊 ${sound.name}`)
        .setDescription("This purchase adds one play of this sound to your inventory.")
        .addFields(
          { name: "Cost", value: `**${SOUNDBOARD_ITEM_COST} coin**`, inline: true },
          { name: "Your Balance", value: `**${balance} coins**`, inline: true },
        ),
    ],
    components: [confirmRow],
  });
}

async function handleSoundboardPurchaseConfirm(
  interaction: ButtonInteraction,
  soundId: string,
): Promise<void> {
  const guild = interaction.guild;
  if (!guild) {
    await interaction.update({ content: "Soundboard sounds can only be bought in a server.", embeds: [], components: [backButton()] });
    return;
  }

  await interaction.deferUpdate();
  const sound = await guild.soundboardSounds.fetch(soundId).catch(() => null);
  if (!sound) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Sound Not Found").setDescription("That sound is no longer available, so no coins were charged.")],
      components: [backButton()],
    });
    return;
  }

  if (!spendCoins(interaction.user.id, SOUNDBOARD_ITEM_COST)) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Not Enough Coins").setDescription(`You need **${SOUNDBOARD_ITEM_COST} coin** to buy one play.`)],
      components: [backButton()],
    });
    return;
  }

  try {
    addItem(interaction.user.id, soundboardInventoryId(guild.id, sound.soundId));
  } catch (error) {
    addCoins(interaction.user.id, SOUNDBOARD_ITEM_COST);
    throw error;
  }

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(0x57f287)
        .setTitle("✅ Sound Added to Inventory")
        .setDescription(`You bought one play of **🔊 ${sound.name}**. Use it from the shop's **Use Items** menu.`)
        .addFields({ name: "New Balance", value: `**${getBalance(interaction.user.id)} coins**` }),
    ],
    components: [mainButtons()],
  });
}

async function useSoundboardItem(
  interaction: StringSelectMenuInteraction,
  itemId: string,
  guildId: string,
  soundId: string,
): Promise<void> {
  await interaction.deferUpdate();

  if (!interaction.guild || interaction.guild.id !== guildId) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Wrong Server").setDescription("This sound can only be used in the server where it was bought.")],
      components: [backButton()],
    });
    return;
  }

  if (!hasItem(interaction.user.id, itemId)) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Item Not Found").setDescription("You don't have a play of that sound.")],
      components: [backButton()],
    });
    return;
  }

  const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  const voiceChannel = member?.voice.channel;
  if (!voiceChannel || voiceChannel.type !== ChannelType.GuildVoice) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Join a Voice Channel").setDescription("Join a standard voice channel before using a soundboard play.")],
      components: [backButton()],
    });
    return;
  }

  const voiceState = member.voice;
  if (voiceState.serverMute || voiceState.serverDeaf || voiceState.selfDeaf || voiceState.suppress) {
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xff6b6b)
          .setTitle("❌ Voice State Blocks Soundboard")
          .setDescription("Discord won't play a sound for a muted, deafened, or suppressed member. Unmute and undeafen, then try again. Your one-use item was not used."),
      ],
      components: [backButton()],
    });
    return;
  }

  const botMember = interaction.guild.members.me;
  const permissions = botMember ? voiceChannel.permissionsFor(botMember) : null;
  if (
    !permissions?.has(PermissionFlagsBits.Connect) ||
    !permissions.has(PermissionFlagsBits.Speak) ||
    !permissions.has(PermissionFlagsBits.UseSoundboard)
  ) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Missing Permission").setDescription("I need Connect, Speak, and Use Soundboard permissions in your voice channel. Your one-use item was not used.")],
      components: [backButton()],
    });
    return;
  }

  const sound = await interaction.guild.soundboardSounds.fetch(soundId).catch(() => null);
  if (!sound) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Sound Not Found").setDescription("That server sound is no longer available. Your play was not used.")],
      components: [backButton()],
    });
    return;
  }

  if (!removeItem(interaction.user.id, itemId)) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Item Not Found").setDescription("You don't have a play of that sound.")],
      components: [backButton()],
    });
    return;
  }

  try {
    await voiceChannel.sendSoundboardSound(sound);
  } catch (error) {
    addItem(interaction.user.id, itemId);
    const apiCode =
      typeof error === "object" && error !== null && "code" in error
        ? String((error as { code?: unknown }).code ?? "unknown")
        : "unknown";
    console.error(`Failed to play shop soundboard sound (Discord API code ${apiCode}):`, error);
    const failureHint =
      apiCode === "50013"
        ? "Discord reports missing permissions. Check Connect, Speak, and Use Soundboard in that voice channel."
        : "Check the bot's PM2 error log for Discord's exact error. Your one-use item has been returned.";
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Couldn't Play Sound").setDescription(failureHint)],
      components: [backButton()],
    });
    return;
  }

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(0x57f287)
        .setTitle("🔊 Sound Played")
        .setDescription(`Played **${sound.name}** in ${voiceChannel}. One use was removed from your inventory.`),
    ],
    components: [mainButtons()],
  });
}

async function showUseMenu(
  interaction: ButtonInteraction | StringSelectMenuInteraction,
  requestedPage = 0,
): Promise<void> {
  await interaction.deferUpdate();

  const balance = getBalance(interaction.user.id);
  const inventory = getInventory(interaction.user.id);
  const entries = Object.entries(inventory).filter(([id, count]) => {
    const soundboardItem = parseSoundboardInventoryId(id);
    return count > 0 && (!soundboardItem || soundboardItem.guildId === interaction.guild?.id);
  });
  const isLocked = interaction.guild ? hasNicknameLock(interaction.guild.id, interaction.user.id) : false;

  const soundboardEntries = entries
    .map(([id]) => parseSoundboardInventoryId(id))
    .filter((item): item is { guildId: string; soundId: string } => item !== null);
  const soundNames = new Map<string, string>();
  if (interaction.guild && soundboardEntries.length > 0) {
    const sounds = await interaction.guild.soundboardSounds.fetch().catch((error) => {
      console.error("Failed to fetch sounds for inventory menu:", error);
      return null;
    });
    for (const sound of sounds?.values() ?? []) soundNames.set(sound.soundId, sound.name);
  }

  const options = entries.map(([id, count]) => {
    const soundboardItem = parseSoundboardInventoryId(id);
    if (soundboardItem) {
      const name = soundNames.get(soundboardItem.soundId) ?? "Unavailable sound";
      return new StringSelectMenuOptionBuilder()
        .setValue(id)
        .setLabel(`🔊 ${name} ×${count}`.slice(0, 100))
        .setDescription("One soundboard play");
    }

    const item = SHOP_ITEMS[id];
    return new StringSelectMenuOptionBuilder()
      .setValue(id)
      .setLabel(`${item?.emoji ?? "📦"} ${item?.name ?? id} ×${count}`.slice(0, 100))
      .setDescription(item?.description ?? "");
  });

  if (isLocked) {
    options.push(
      new StringSelectMenuOptionBuilder()
        .setValue("unlock_nickname")
        .setLabel(`↩️ Revert Name Change — ${UNLOCK_NICKNAME_COST} coins`)
        .setDescription("Revert your nickname back to your original Discord name")
    );
  }

  if (options.length === 0) {
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xff6b6b)
          .setTitle("🎒 Your Items")
          .setDescription("You don't have any items yet — buy some first!"),
      ],
      components: [backButton()],
    });
    return;
  }

  const pageCount = Math.ceil(options.length / 25);
  const page = Math.max(0, Math.min(Math.floor(requestedPage), pageCount - 1));
  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`shop_use_select_${page}`)
      .setPlaceholder("Choose an item to use...")
      .addOptions(options.slice(page * 25, (page + 1) * 25))
  );
  const components = [selectRow] as ActionRowBuilder<any>[];

  if (pageCount > 1) {
    components.push(
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId(`shop_use_page_${page - 1}`)
          .setLabel("Previous")
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(page === 0),
        new ButtonBuilder()
          .setCustomId(`shop_use_page_${page + 1}`)
          .setLabel("Next")
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(page === pageCount - 1),
      )
    );
  }
  components.push(backButton());

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(0x57f287)
        .setTitle("🎒 Your Items")
        .setDescription("Select an item to use it. Soundboard plays use one sound in your current voice channel.")
        .addFields({ name: "💰 Your Balance", value: `**${balance} coin${balance === 1 ? "" : "s"}**` })
        .setFooter({ text: `Page ${page + 1} of ${pageCount}` }),
    ],
    components,
  });
}

export const shopCommand = new SlashCommandBuilder()
  .setName("shop")
  .setDescription("Open the server shop");

export async function shopExecute(interaction: ChatInputCommandInteraction): Promise<void> {
  const balance = getBalance(interaction.user.id);
  await interaction.reply({ embeds: [mainEmbed(balance)], components: [mainButtons()] });
}

type ShopInteraction =
  | ButtonInteraction
  | StringSelectMenuInteraction
  | UserSelectMenuInteraction
  | ModalSubmitInteraction;

export async function handleShopInteraction(interaction: ShopInteraction): Promise<void> {
  try {
    if (interaction.isButton())                await handleButton(interaction);
    else if (interaction.isStringSelectMenu()) await handleStringSelect(interaction);
    else if (interaction.isUserSelectMenu())   await handleUserSelect(interaction);
    else if (interaction.isModalSubmit())      await handleModal(interaction);
  } catch (err) {
    console.error("Shop interaction error:", err);
    const errEmbed = new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Something went wrong").setDescription("Please try again.");
    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply({ embeds: [errEmbed], components: [backButton()] });
      } else if (interaction.isModalSubmit()) {
        await interaction.reply({ embeds: [errEmbed], flags: MessageFlags.Ephemeral });
      } else {
        await (interaction as ButtonInteraction).update({ embeds: [errEmbed], components: [backButton()] });
      }
    } catch { /* swallow */ }
  }
}

async function handleButton(interaction: ButtonInteraction): Promise<void> {
  const { customId, user } = interaction;
  const balance = getBalance(user.id);

  if (customId === "shop_back") {
    await interaction.update({ embeds: [mainEmbed(balance)], components: [mainButtons()] });
    return;
  }

  if (customId.startsWith("shop_soundboard_page_")) {
    const page = Number(customId.replace("shop_soundboard_page_", ""));
    await showSoundboardShop(interaction, Number.isFinite(page) ? page : 0);
    return;
  }

  if (customId.startsWith("shop_use_page_")) {
    const page = Number(customId.replace("shop_use_page_", ""));
    await showUseMenu(interaction, Number.isFinite(page) ? page : 0);
    return;
  }

  if (customId.startsWith("shop_confirm_soundboard_")) {
    const soundId = customId.replace("shop_confirm_soundboard_", "");
    await handleSoundboardPurchaseConfirm(interaction, soundId);
    return;
  }

  if (customId === "shop_open_buy") {
    const options = Object.entries(SHOP_ITEMS).map(([id, item]) =>
      new StringSelectMenuOptionBuilder()
        .setValue(id)
        .setLabel(`${item.emoji} ${item.name} — ${item.cost} coins`)
        .setDescription(item.description)
    );
    options.push(
      new StringSelectMenuOptionBuilder()
        .setValue("shop_buy_soundboard")
        .setLabel("🔊 Server Soundboard — 1 coin per play")
        .setDescription("Buy one-use plays of sounds saved in this server.")
    );

    const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("shop_buy_select")
        .setPlaceholder("Choose an item to buy...")
        .addOptions(options)
    );

    await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setColor(0xffd700)
          .setTitle("🛒 Buy an Item")
          .setDescription("Pick something from the dropdown — you'll confirm before spending coins.")
          .addFields({ name: "💰 Your Balance", value: `**${balance} coin${balance === 1 ? "" : "s"}**` }),
      ],
      components: [selectRow, backButton()],
    });
    return;
  }

  if (customId === "shop_open_use") {
    await showUseMenu(interaction);
    return;
  }

  if (customId.startsWith("shop_confirm_")) {
    const itemId = customId.replace("shop_confirm_", "");
    const item = SHOP_ITEMS[itemId];
    if (!item) return;

    if (balance < item.cost) {
      await interaction.update({
        embeds: [
          new EmbedBuilder()
            .setColor(0xff6b6b)
            .setTitle("❌ Not Enough Coins")
            .setDescription(`You need **${item.cost} coins** but only have **${balance}**.`),
        ],
        components: [backButton()],
      });
      return;
    }

    const success = spendCoins(user.id, item.cost);
    if (!success) { await interaction.update({ content: "Purchase failed. Try again.", embeds: [], components: [] }); return; }

    const newBalance = getBalance(user.id);

    if (itemId === "uno_reverse") {
      activateUnoReverse(user.id);
      await interaction.update({
        embeds: [
          new EmbedBuilder()
            .setColor(0xff3300)
            .setTitle("🔄 UNO Reverse Activated!")
            .setDescription(`Your UNO Reverse card is now active! The next item anyone uses on you within 12 hours will be reversed back onto them.`)
            .addFields({ name: "💰 New Balance", value: `**${newBalance} coin${newBalance === 1 ? "" : "s"}**`, inline: true })
            .setFooter({ text: "Expires in 12 hours or after one use — whichever comes first." }),
        ],
        components: [mainButtons()],
      });
    } else {
      addItem(user.id, itemId);
      await interaction.update({
        embeds: [
          new EmbedBuilder()
            .setColor(0x57f287)
            .setTitle("✅ Purchased!")
            .setDescription(`You bought **${item.emoji} ${item.name}** and it's in your inventory!`)
            .addFields({ name: "💰 New Balance", value: `**${newBalance} coin${newBalance === 1 ? "" : "s"}**`, inline: true })
            .setFooter({ text: 'Use it via "Use Items"' }),
        ],
        components: [mainButtons()],
      });
      await (interaction.channel as import("discord.js").TextChannel | null)?.send(`🛒 **${user.displayName}** bought **${item.emoji} ${item.name}** from the store for **${item.cost} coin${item.cost === 1 ? "" : "s"}**!`);
    }
    return;
  }
}

async function handleStringSelect(interaction: StringSelectMenuInteraction): Promise<void> {
  const { customId, user, values } = interaction;
  const selected = values[0]!;
  const balance = getBalance(user.id);

  if (customId.startsWith("shop_soundboard_select_")) {
    await showSoundboardPurchaseConfirmation(interaction, selected);
    return;
  }

  if (customId === "shop_buy_select") {
    if (selected === "shop_buy_soundboard") {
      await showSoundboardShop(interaction);
      return;
    }

    const item = SHOP_ITEMS[selected];
    if (!item) return;

    const canAfford = balance >= item.cost;

    const confirmRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`shop_confirm_${selected}`)
        .setLabel(`Buy for ${item.cost} coins`)
        .setEmoji("✅")
        .setStyle(ButtonStyle.Success)
        .setDisabled(!canAfford),
      new ButtonBuilder()
        .setCustomId("shop_back")
        .setLabel("Cancel")
        .setStyle(ButtonStyle.Secondary),
    );

    await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setColor(canAfford ? 0xffd700 : 0xff6b6b)
          .setTitle(`${item.emoji} ${item.name}`)
          .setDescription(item.description)
          .addFields(
            { name: "Cost", value: `**${item.cost} coins**`, inline: true },
            { name: "Your Balance", value: `**${balance} coins**`, inline: true },
            ...(canAfford ? [] : [{ name: "⚠️", value: `You need ${item.cost - balance} more coins.` }])
          ),
      ],
      components: [confirmRow],
    });
    return;
  }

  if (/^shop_use_select(?:_\d+)?$/.test(customId)) {
    const soundboardItem = parseSoundboardInventoryId(selected);
    if (soundboardItem) {
      await useSoundboardItem(interaction, selected, soundboardItem.guildId, soundboardItem.soundId);
      return;
    }

    if (selected === "unlock_nickname") {
      if (!interaction.guild) return;
      if (balance < UNLOCK_NICKNAME_COST) {
        await interaction.update({
          embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Not Enough Coins").setDescription(`You need **${UNLOCK_NICKNAME_COST} coins** but only have **${balance}**.`)],
          components: [backButton()],
        });
        return;
      }
      spendCoins(user.id, UNLOCK_NICKNAME_COST);
      const lock = getNicknameLock(interaction.guild.id, user.id);
      removeNicknameLock(interaction.guild.id, user.id);
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      const originalName = lock?.originalUsername ?? null;
      await member?.setNickname(originalName, "Name reverted to original").catch(() => null);
      const newBalance = getBalance(user.id);
      await interaction.update({
        embeds: [
          new EmbedBuilder()
            .setColor(0x57f287)
            .setTitle("↩️ Name Reverted!")
            .setDescription(`Your nickname has been reverted back to your original Discord name${originalName ? ` (**${originalName}**)` : ""}.`)
            .addFields({ name: "💰 New Balance", value: `**${newBalance} coin${newBalance === 1 ? "" : "s"}**` }),
        ],
        components: [mainButtons()],
      });
      return;
    }

    const item = SHOP_ITEMS[selected];
    if (!item) return;

    if (!hasItem(user.id, selected)) {
      await interaction.update({
        embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Item Not Found").setDescription("You don't have that item.")],
        components: [backButton()],
      });
      return;
    }

    const userSelectRow = new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(
      new UserSelectMenuBuilder()
        .setCustomId(`shop_target_${selected}`)
        .setPlaceholder("Select who to use this on...")
        .setMinValues(1)
        .setMaxValues(1)
    );

    await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setColor(0xffd700)
          .setTitle(`${item.emoji} ${item.name}`)
          .setDescription(
            item.needsNickname
              ? "Select the target — you'll type the nickname next."
              : "Select who to use this on."
          )
          .addFields(
            ...(item.needsVoice ? [{ name: "⚠️ Note", value: "Target must be in a voice channel." }] : [])
          ),
      ],
      components: [userSelectRow, backButton()],
    });
    return;
  }
}

async function handleUserSelect(interaction: UserSelectMenuInteraction): Promise<void> {
  const { customId, user, values } = interaction;
  if (!customId.startsWith("shop_target_")) return;

  const itemId = customId.replace("shop_target_", "");
  const item = SHOP_ITEMS[itemId];
  if (!item) return;

  const targetId = values[0]!;

  if (targetId === user.id && itemId !== "set_nickname") {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Invalid Target").setDescription("You can't use this on yourself.")],
      components: [backButton()],
    });
    return;
  }

  const targetUser = await interaction.client.users.fetch(targetId).catch(() => null);
  if (targetUser?.bot) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Invalid Target").setDescription("You can't use this on a bot.")],
      components: [backButton()],
    });
    return;
  }

  const PROTECTED_USER_ID = "463733669304074240";
  if (itemId === "set_nickname" && targetId === PROTECTED_USER_ID) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Protected User").setDescription("You can't change that person's nickname.")],
      components: [backButton()],
    });
    return;
  }

  if (item.needsNickname) {
    const modal = new ModalBuilder()
      .setCustomId(`shop_nickname_modal_${targetId}`)
      .setTitle("Set Nickname");

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("nickname_input")
          .setLabel("Enter the nickname")
          .setStyle(TextInputStyle.Short)
          .setMaxLength(32)
          .setRequired(true)
      )
    );

    await interaction.showModal(modal);
    return;
  }

  await executeAction(interaction, itemId, targetId, item);
}

async function handleModal(interaction: ModalSubmitInteraction): Promise<void> {
  if (!interaction.customId.startsWith("shop_nickname_modal_")) return;

  const targetId = interaction.customId.replace("shop_nickname_modal_", "");
  const nickname = interaction.fields.getTextInputValue("nickname_input");
  const userId = interaction.user.id;

  if (!interaction.guild) {
    await interaction.reply({ content: "This can only be used in a server.", flags: MessageFlags.Ephemeral });
    return;
  }

  if (!hasItem(userId, "set_nickname")) {
    await interaction.reply({ embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Item Not Found").setDescription("You don't have that item.")], flags: MessageFlags.Ephemeral });
    return;
  }

  const target = await interaction.guild.members.fetch(targetId).catch(() => null);
  if (!target) {
    await interaction.reply({ embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Error").setDescription("Couldn't find that member.")], flags: MessageFlags.Ephemeral });
    return;
  }

  const PROTECTED_USER_ID = "463733669304074240";
  if (targetId === PROTECTED_USER_ID) {
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Protected User").setDescription("You can't change that person's nickname.")],
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const botMember = interaction.guild.members.me;
  if (!botMember?.permissions.has(PermissionFlagsBits.ManageNicknames)) {
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Failed").setDescription("I don't have permission to manage nicknames. Item kept.")],
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  removeItem(userId, "set_nickname");
  const originalUsername = target.user.username;
  const nicknameSet = await target.setNickname(nickname, `Shop item used by ${interaction.user.username}`).then(() => true).catch(() => false);
  if (!nicknameSet) {
    addItem(userId, "set_nickname");
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Failed").setDescription(`Couldn't change **${target.displayName}**'s nickname — Discord rejected it (they may outrank the bot). Item returned.`)],
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  setNicknameLock(interaction.guild.id, targetId, nickname, userId, originalUsername);

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor(0x57f287)
        .setTitle("✏️ Nickname Set!")
        .setDescription(`**${target.displayName}**'s nickname is now **${nickname}** and it's locked.\nThey'll need **${UNLOCK_NICKNAME_COST} coins** and \`/shop\` → Use Items → Revert Name Change to get it back.`),
    ],
    flags: MessageFlags.Ephemeral,
  });
}

async function applyActionToMember(
  guild: Guild,
  itemId: string,
  item: (typeof SHOP_ITEMS)[string],
  target: GuildMember,
  usedBy: string
): Promise<void> {
  const botMember = guild.members.me;
  switch (itemId) {
    case "timeout_10s":
      if (target.moderatable) await target.timeout(60_000, `UNO Reverse — originally by ${usedBy}`).catch(() => null);
      break;
    case "server_mute_10s":
      if (target.voice.channel && botMember?.permissions.has(PermissionFlagsBits.MuteMembers)) {
        await target.voice.setMute(true, "UNO Reverse").catch(() => null);
        setTimeout(() => target.voice.setMute(false, "UNO Reverse mute expired").catch(() => null), 40_000);
      }
      break;
    case "server_deafen_10s":
      if (target.voice.channel && botMember?.permissions.has(PermissionFlagsBits.DeafenMembers)) {
        await target.voice.setDeaf(true, "UNO Reverse").catch(() => null);
        setTimeout(() => target.voice.setDeaf(false, "UNO Reverse deafen expired").catch(() => null), 30_000);
      }
      break;
    case "move_to_afk": {
      const afkChannel = guild.channels.cache.find(
        (ch): ch is VoiceChannel =>
          ch.type === ChannelType.GuildVoice &&
          ch.name.toLowerCase() === (process.env["AFK_CHANNEL_NAME"] ?? "afk").toLowerCase()
      );
      if (target.voice.channel && afkChannel && botMember?.permissions.has(PermissionFlagsBits.MoveMembers)) {
        await target.voice.setChannel(afkChannel, "UNO Reverse").catch(() => null);
      }
      break;
    }
    case "text_channel_lock": {
      const textChannel = guild.channels.cache.get(TEXT_LOCK_CHANNEL_ID) as TextChannel | undefined;
      if (textChannel && guild.members.me?.permissionsIn(textChannel).has(PermissionFlagsBits.ManageChannels)) {
        await textChannel.permissionOverwrites.create(target, { ViewChannel: false }, { reason: "UNO Reverse" }).catch(() => null);
        setTimeout(async () => {
          await textChannel.permissionOverwrites.delete(target, "UNO Reverse text lock expired").catch(() => null);
        }, 30 * 60 * 1000);
      }
      break;
    }
    case "voice_channel_lock": {
      const voiceChannel = guild.channels.cache.get(VOICE_LOCK_CHANNEL_ID) as VoiceChannel | undefined;
      if (voiceChannel && guild.members.me?.permissionsIn(voiceChannel).has(PermissionFlagsBits.ManageChannels)) {
        if (target.voice.channelId === VOICE_LOCK_CHANNEL_ID) {
          await target.voice.disconnect("UNO Reverse").catch(() => null);
        }
        await voiceChannel.permissionOverwrites.create(target, { Connect: false }, { reason: "UNO Reverse" }).catch(() => null);
        setTimeout(async () => {
          await voiceChannel.permissionOverwrites.delete(target, "UNO Reverse voice lock expired").catch(() => null);
        }, 60 * 60 * 1000);
      }
      break;
    }
  }
}

async function executeAction(
  interaction: UserSelectMenuInteraction,
  itemId: string,
  targetId: string,
  item: (typeof SHOP_ITEMS)[string]
): Promise<void> {
  const { user } = interaction;
  if (!interaction.guild) return;

  const target = await interaction.guild.members.fetch(targetId).catch(() => null);
  if (!target) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Error").setDescription("Couldn't find that member.")],
      components: [backButton()],
    });
    return;
  }

  if (!hasItem(user.id, itemId)) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Item Not Found").setDescription("You don't have that item.")],
      components: [backButton()],
    });
    return;
  }

  removeItem(user.id, itemId);

  if (hasUnoReverse(targetId)) {
    consumeUnoReverse(targetId);
    const attackerMember = await interaction.guild.members.fetch(user.id).catch(() => null);
    await (interaction.channel as import("discord.js").TextChannel | null)?.send(`🔄 **${user.displayName}** tried to use **${item.emoji} ${item.name}** on **${target.displayName}** but **${target.displayName}** had an **UNO Reverse!** 💥 It backfired on **${user.displayName}**!`);
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(0xff3300).setTitle("🔄 UNO Reverse!").setDescription(`**${target.displayName}** had an UNO Reverse card! **${item.emoji} ${item.name}** was used on you instead!`)],
      components: [mainButtons()],
    });
    if (attackerMember) {
      await applyActionToMember(interaction.guild, itemId, item, attackerMember, user.username);
    }
    return;
  }

  const botMember = interaction.guild.members.me;

  const fail = async (reason: string) => {
    addItem(user.id, itemId);
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Failed").setDescription(`${reason}\n\nYour item has been returned.`)],
      components: [backButton()],
    });
  };

  try {
    switch (itemId) {
      case "timeout_10s": {
        if (!target.moderatable) { await fail(`Can't timeout **${target.displayName}** — they have a higher role.`); return; }
        await target.timeout(60_000, `Shop item used by ${user.username}`);
        await interaction.update({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("☠️ Done!").setDescription(`**${user.displayName}** timed out **${target.displayName}** for 10 seconds!`)],
          components: [mainButtons()],
        });
        await (interaction.channel as import("discord.js").TextChannel | null)?.send(`☠️ **${user.displayName}** has timed out **${target.displayName}** for 10 seconds!`);
        break;
      }
      case "server_mute_10s": {
        if (!target.voice.channel) { await fail(`**${target.displayName}** isn't in a voice channel.`); return; }
        if (!botMember?.permissions.has(PermissionFlagsBits.MuteMembers)) { await fail("I don't have permission to mute members."); return; }
        await target.voice.setMute(true, `Shop item used by ${user.username}`);
        await interaction.update({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("🔇 Done!").setDescription(`**${user.displayName}** muted **${target.displayName}** for 10 seconds!`)],
          components: [mainButtons()],
        });
        await (interaction.channel as import("discord.js").TextChannel | null)?.send(`🔇 **${user.displayName}** has muted **${target.displayName}** for 10 seconds!`);
        setTimeout(() => target.voice.setMute(false, "Shop mute expired").catch(() => null), 40_000);
        break;
      }
      case "server_deafen_10s": {
        if (!target.voice.channel) { await fail(`**${target.displayName}** isn't in a voice channel.`); return; }
        if (!botMember?.permissions.has(PermissionFlagsBits.DeafenMembers)) { await fail("I don't have permission to deafen members."); return; }
        await target.voice.setDeaf(true, `Shop item used by ${user.username}`);
        await interaction.update({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("🔕 Done!").setDescription(`**${user.displayName}** deafened **${target.displayName}** for 4 seconds!`)],
          components: [mainButtons()],
        });
        await (interaction.channel as import("discord.js").TextChannel | null)?.send(`🔕 **${user.displayName}** has deafened **${target.displayName}** for 4 seconds!`);
        setTimeout(() => target.voice.setDeaf(false, "Shop deafen expired").catch(() => null), 30_000);
        break;
      }
      case "move_to_afk": {
        if (!target.voice.channel) { await fail(`**${target.displayName}** isn't in a voice channel.`); return; }
        if (!botMember?.permissions.has(PermissionFlagsBits.MoveMembers)) { await fail("I don't have permission to move members."); return; }
        const afkChannel = interaction.guild.channels.cache.find(
          (ch): ch is VoiceChannel =>
            ch.type === ChannelType.GuildVoice &&
            ch.name.toLowerCase() === (process.env["AFK_CHANNEL_NAME"] ?? "afk").toLowerCase()
        );
        if (!afkChannel) { await fail("No AFK channel found."); return; }
        await target.voice.setChannel(afkChannel, `Shop item used by ${user.username}`);
        await interaction.update({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("🚀 Done!").setDescription(`**${user.displayName}** yeeted **${target.displayName}** to AFK!`)],
          components: [mainButtons()],
        });
        await (interaction.channel as import("discord.js").TextChannel | null)?.send(`🚀 **${user.displayName}** has yeeted **${target.displayName}** to AFK!`);
        break;
      }
      case "text_channel_lock": {
        const textChannel = interaction.guild.channels.cache.get(TEXT_LOCK_CHANNEL_ID) as TextChannel | undefined;
        if (!textChannel) { await fail("Couldn't find the text channel."); return; }
        if (!interaction.guild.members.me?.permissionsIn(textChannel).has(PermissionFlagsBits.ManageChannels)) {
          await fail("I don't have permission to manage that channel."); return;
        }
        await textChannel.permissionOverwrites.create(target, { ViewChannel: false }, { reason: `Shop item used by ${user.username}` });
        await interaction.update({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("🔒 Done!").setDescription(`**${user.displayName}** locked **${target.displayName}** out of the text channel for 30 minutes!`)],
          components: [mainButtons()],
        });
        await (interaction.channel as import("discord.js").TextChannel | null)?.send(`🔒 **${user.displayName}** has locked **${target.displayName}** out of the text channel for 30 minutes!`);
        setTimeout(async () => {
          await textChannel.permissionOverwrites.delete(target, "Shop text lock expired").catch(() => null);
        }, 30 * 60 * 1000);
        break;
      }
      case "voice_channel_lock": {
        const voiceChannel = interaction.guild.channels.cache.get(VOICE_LOCK_CHANNEL_ID) as VoiceChannel | undefined;
        if (!voiceChannel) { await fail("Couldn't find the voice channel."); return; }
        if (!interaction.guild.members.me?.permissionsIn(voiceChannel).has(PermissionFlagsBits.ManageChannels)) {
          await fail("I don't have permission to manage that channel."); return;
        }
        if (target.voice.channelId === VOICE_LOCK_CHANNEL_ID) {
          await target.voice.disconnect(`Shop item used by ${user.username}`).catch(() => null);
        }
        await voiceChannel.permissionOverwrites.create(target, { Connect: false }, { reason: `Shop item used by ${user.username}` });
        await interaction.update({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("🔈 Done!").setDescription(`**${user.displayName}** locked **${target.displayName}** out of the voice channel for 1 hour!`)],
          components: [mainButtons()],
        });
        await (interaction.channel as import("discord.js").TextChannel | null)?.send(`🔈 **${user.displayName}** has locked **${target.displayName}** out of the voice channel for 1 hour!`);
        setTimeout(async () => {
          await voiceChannel.permissionOverwrites.delete(target, "Shop voice lock expired").catch(() => null);
        }, 60 * 60 * 1000);
        break;
      }
    }
  } catch (err) {
    console.error("Shop action error:", err);
    addItem(user.id, itemId);
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(0xff6b6b).setTitle("❌ Error").setDescription("Something went wrong. Your item has been returned.")],
      components: [backButton()],
    });
  }
}
