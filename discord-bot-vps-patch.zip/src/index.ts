import dotenv from "dotenv";
dotenv.config();
import {
  Client,
  Collection,
  Events,
  GatewayIntentBits,
  Interaction,
  ChatInputCommandInteraction,
  ButtonInteraction,
} from "discord.js";

import { pingCommand, pingExecute } from "./commands/ping.js";
import { banCommand, banExecute } from "./commands/ban.js";
import { vctimeCommand, vctimeExecute } from "./commands/vctime.js";
import { nukeCommand, nukeExecute } from "./commands/nuke.js";
import { shopCommand, shopExecute, handleShopInteraction } from "./commands/shop.js";
import { balanceCommand, balanceExecute } from "./commands/balance.js";
import { giveCoinCommand, giveCoinExecute } from "./commands/givecoin.js";
import { seeInventoryCommand, seeInventoryExecute, handleAdminInvInteraction } from "./commands/seeinventory.js";
import { seeCoinsCommand, seeCoinsExecute } from "./commands/seecoins.js";
import { prayCommand, prayExecute } from "./commands/pray.js";
import { chatLeaderboardCommand, chatLeaderboardExecute } from "./commands/chatleaderboard.js";
import { sendCoinCommand, sendCoinExecute } from "./commands/sendcoin.js";
import { eventCommand, eventExecute, handleEventInteraction } from "./commands/event.js";

import {
  handleVoiceStateUpdate,
  startCoinInterval,
} from "./events/voiceStateUpdate.js";

import {
  handleAfkVoiceStateUpdate,
  startAfkVoiceMonitor,
} from "./events/afkVoiceMonitor.js";

import { handleMessageCreate } from "./events/messageCreate.js";
import { startBanterScheduler } from "./events/banter.js";
import { getNicknameLock } from "./store/nicknameLock.js";
import { setVcStatsClient } from "./store/vcStats.js";
import { setChatStatsClient } from "./store/chatStats.js";

export function startBot(): void {
  const token = process.env["DISCORD_BOT_TOKEN"];
  if (!token) {
    console.warn("??  DISCORD_BOT_TOKEN not set � bot will not start");
    return;
  }

  process.on("unhandledRejection", (reason) => {
    console.error("Unhandled rejection:", reason);
  });

  const commands = new Collection<string, (interaction: ChatInputCommandInteraction) => Promise<void>>();
  commands.set(pingCommand.name, pingExecute);
  commands.set(banCommand.name, banExecute);
  commands.set(vctimeCommand.name, vctimeExecute);
  commands.set(nukeCommand.name, nukeExecute);
  commands.set(shopCommand.name, shopExecute);
  commands.set(balanceCommand.name, balanceExecute);
  commands.set(giveCoinCommand.name, giveCoinExecute);
  commands.set(seeInventoryCommand.name, seeInventoryExecute);
  commands.set(seeCoinsCommand.name, seeCoinsExecute);
  commands.set(prayCommand.name, prayExecute);
  commands.set(chatLeaderboardCommand.name, chatLeaderboardExecute);
  commands.set(sendCoinCommand.name, sendCoinExecute);
  commands.set(eventCommand.name, eventExecute);

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildVoiceStates,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
  });

  client.once(Events.ClientReady, (readyClient) => {
    console.log(`?? Logged in as ${readyClient.user.tag}`);
    setVcStatsClient(readyClient);
    setChatStatsClient(readyClient);
    startCoinInterval(readyClient);
    startBanterScheduler(readyClient);
    startAfkVoiceMonitor(readyClient);
  });

  client.on(Events.VoiceStateUpdate, (oldState, newState) => {
    handleVoiceStateUpdate(oldState, newState);
    handleAfkVoiceStateUpdate(oldState, newState);
  });

  client.on(Events.MessageCreate, (message) => {
    handleMessageCreate(message).catch(console.error);
  });

  client.on(Events.GuildMemberUpdate, async (_oldMember, newMember) => {
    if (newMember.user.bot) return;
    const lock = getNicknameLock(newMember.guild.id, newMember.id);
    if (!lock) return;
    if (newMember.nickname === lock.nickname) return;
    await newMember.setNickname(lock.nickname, "Nickname is locked by shop").catch(() => null);
  });

  client.on(Events.InteractionCreate, async (interaction: Interaction) => {
    if (
      (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isUserSelectMenu() || interaction.isModalSubmit()) &&
      (interaction as ButtonInteraction).customId?.startsWith("shop_")
    ) {
      await handleShopInteraction(interaction as ButtonInteraction).catch(console.error);
      return;
    }

    if (
      (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isUserSelectMenu()) &&
      (interaction as ButtonInteraction).customId?.startsWith("admin_inv_")
    ) {
      await handleAdminInvInteraction(interaction as ButtonInteraction).catch(console.error);
      return;
    }

    if (interaction.isButton() && interaction.customId.startsWith("event_claim_")) {
      await handleEventInteraction(interaction).catch(console.error);
      return;
    }

    if (!interaction.isChatInputCommand()) return;

    const execute = commands.get(interaction.commandName);
    if (!execute) {
      console.warn(`Unknown command: ${interaction.commandName}`);
      return;
    }

    try {
      await execute(interaction);
    } catch (error) {
      console.error(`Error executing /${interaction.commandName}:`, error);
      const reply = { content: "An error occurred while executing this command.", ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(reply);
      } else {
        await interaction.reply(reply);
      }
    }
  });

  client.login(token).catch((err) => {
    console.error("Failed to login to Discord:", err);
  });
}

startBot();
