import dotenv from "dotenv";
dotenv.config();
import { REST, Routes } from "discord.js";

import { pingCommand } from "./commands/ping.js";
import { banCommand } from "./commands/ban.js";
import { vctimeCommand } from "./commands/vctime.js";
import { nukeCommand } from "./commands/nuke.js";
import { shopCommand } from "./commands/shop.js";
import { balanceCommand } from "./commands/balance.js";
import { giveCoinCommand } from "./commands/givecoin.js";
import { seeInventoryCommand } from "./commands/seeinventory.js";
import { seeCoinsCommand } from "./commands/seecoins.js";
import { prayCommand } from "./commands/pray.js";
import { chatLeaderboardCommand } from "./commands/chatleaderboard.js";
import { sendCoinCommand } from "./commands/sendcoin.js";
import { eventCommand } from "./commands/event.js";
const token = process.env["DISCORD_BOT_TOKEN"];
const clientId = process.env["DISCORD_CLIENT_ID"];
const guildId = process.env["DISCORD_GUILD_ID"];

if (!token || !clientId) {
  console.error("Missing DISCORD_BOT_TOKEN or DISCORD_CLIENT_ID");
  process.exit(1);
}

const commands = [
  pingCommand,
  banCommand,
  vctimeCommand,
  nukeCommand,
  shopCommand,
  balanceCommand,
  giveCoinCommand,
  seeInventoryCommand,
  seeCoinsCommand,
  prayCommand,
  chatLeaderboardCommand,
  sendCoinCommand,
  eventCommand,
].map((c) => c.toJSON());

const rest = new REST({ version: "10" }).setToken(token);

(async () => {
  try {
    console.log(`Deploying ${commands.length} slash commands…`);

    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log(`✅ Deployed to guild ${guildId}`);
    } else {
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log("✅ Deployed globally");
    }
  } catch (err) {
    console.error("Deploy failed:", err);
    process.exit(1);
  }
})();
